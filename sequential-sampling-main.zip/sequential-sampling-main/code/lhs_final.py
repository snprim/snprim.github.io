# Space-filling LHS
# Three choices of function: 
#     (1) mm_cb: multimodal and camel with two ideal points
#     (2) double_gram (dg): from Gramacy an dLee (2008)
#     (3) 3D: multimodal, ishigami, and y3
# Two choices of surrogate model: 
#     (1) gp: scikit-learn GPR
#     (2) dgp: two-layer deep GP
# Method: 
#     LHS

import sys
sys.path.append('code')
import utils_all as utils_all
import utils_mm_cb as mm_cb
import utils_double_gram as double_gram
import utils_mm_ishigami as mm_ishigami
import numpy as np
from pyDOE import lhs
import warnings
warnings.filterwarnings(action = "ignore", category = RuntimeWarning)

import time
import random

start_time = time.time()

args = sys.argv[1:]  # This will get all arguments except the script name
seed = int(args[0])
func = str(args[1])
random.seed(seed)

if func == "dg" or func == "mm_cb":
    n0 = 5
    budget = 20

elif func == "mm_ishigami":
    n0 = 10
    budget = 30

total = n0+budget
epsilon = 1e-3

# training set
file_name_x = 'code/data/x_' + func + '_' + str(seed) + '.csv'
file_name_y = 'code/data/y_' + func + '_' + str(seed) + '.csv'

train_X = np.loadtxt(file_name_x, delimiter=',')
train_Y = np.loadtxt(file_name_y, delimiter=',')

d = train_X.shape[1]
M = train_Y.shape[1]

result = np.zeros(((n0+budget+1),(d+1)))
result[:] = np.nan

xx = lhs(d, n0+budget)
result[1:,0:d] = xx

if func=="mm_cb":
    yy = mm_cb.mm_cb(xx)

elif func=="dg":
    yy = double_gram.double_gram(xx)

elif func=="mm_ishigami":
    yy = mm_ishigami.mm_ishigami(xx)

result[(n0+budget),d] = min(np.sum(np.power(yy,2), axis = 1))

for i in range(n0,n0+budget):
    print(i)

    ##### calculate performance starts here #####
    train_X = xx[:i,:]
    train_Y = yy[:i,:]
    
    result[(i),d] = min(np.sum(np.power(train_Y,2), axis = 1))

# store result

result_name = 'result/' + str(func) + '_lhs_final_seed' + str(seed) + '.csv'

np.savetxt(result_name, result, delimiter=',', comments='')

end_time = time.time()
execution_time = end_time - start_time
print(f"Execution time: {execution_time:.6f} seconds")