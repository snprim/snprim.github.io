import os
import sys
sys.path.append('code')
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

import utils_mm_cb as mm_cb
import utils_double_gram as double_gram
import utils_all as utils_all

from scipy.stats import norm
import warnings
warnings.filterwarnings(action = "ignore", category = RuntimeWarning)
    # for entropy calculation on really small or large probabilities

from GP import GPyModelEasy as GP
import random

from pyDOE import lhs


# Figures 1 and 6: Heatmaps of Multimodal-Camelback and Double-Gramacy -------

### See Figures_R.R

# Figure 2: Slices of Multimodal and Camelback --------------------------------

###################################
########## plot 2D slice ##########
###################################

budget = 20
g1 = np.linspace(0, 1, 101)
method = "joint_pareto"
seed = 0
random.seed(seed)
result_name = 'mm_cb_' + method + '_final_seed' + str(seed) + '.csv'
# the columns in the result: (acquired point x1, x2), min dist, tol, lowest_prob, a number that indicates algorithm stops there
model = np.loadtxt(result_name, delimiter=',')

test_X = np.loadtxt('test_x_mm_cb.csv', delimiter=',')
test_Y = np.loadtxt('test_y_mm_cb.csv', delimiter=',')

outcome_mm = test_Y[:,0].reshape(101,101)
outcome_cb = test_Y[:,1].reshape(101,101)

file_name_x = 'x_mm_cb_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'y_mm_cb_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')
d = 2

############# First Plots ###################
 
train_X = np.loadtxt(file_name_x, delimiter=',')
train_Y = np.loadtxt(file_name_y, delimiter=',')

# training set only
X = train_X
Y = train_Y

gp1 = GP.GPyModel(X, Y[:,0].reshape(-1,1))
gp1.nugbnd = [1e-16,1e-6]
gp1.rand_restarts = 10
gp1.Fit()
mu1, var1 = gp1.predict(test_X)
var1 = var1.reshape(-1,1)
s1 = np.sqrt(var1).reshape(-1,1)

gp2 = GP.GPyModel(X, Y[:,1].reshape(-1,1))
gp2.nugbnd = [1e-16,1e-6]
gp2.rand_restarts = 10
gp2.Fit()
mu2, var2 = gp2.predict(test_X)
var2 = var2.reshape(-1,1)
s2 = np.sqrt(var2).reshape(-1,1)

mu1_plot = mu1.reshape(101,101)
s1_plot = s1.reshape(101,101)

mu2_plot = mu2.reshape(101,101)
s2_plot = s2.reshape(101,101)

limit = 0

# training set only
tol = (model[0,d+1])
prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)

joint_prob = (prob1*prob2).reshape(101, 101)

# 2D slice plot 

lower1 = mu1_plot - 1.96*s1_plot
upper1 = mu1_plot + 1.96*s1_plot

lower2 = mu2_plot - 1.96*s2_plot
upper2 = mu2_plot + 1.96*s2_plot

slice_ind = 52

# Two axes

plt.clf()
fig, ax1 = plt.subplots()
ax1.plot(g1, outcome_mm[slice_ind], label = 'True Multimodal function', color = "black")
ax1.plot(g1, mu1_plot[slice_ind], label = 'GP prediction')
ax1.plot(.86, 0, marker = 'o', color = "purple", markersize = 6)
ax1.fill_between(g1, lower1[slice_ind], upper1[slice_ind], color='blue', alpha=0.2, label='Confidence Interval')
# ax1.fill_between(g1, -tol, tol, color='green', alpha = .2, label='Target value')
# ax1.axhline(0, color = 'green')
ax1.axhline(tol, color = 'green',  linestyle='--')
ax1.axhline(-tol, color = 'green',  linestyle='--')
ax1.set_ylabel('Multimodal value', color='b')
ax1.set_xlabel('x1')
ax1.tick_params(axis='y', labelcolor = 'b')
ax1.set_ylim(-1.75,1)
# ax1.legend()
ax2 = ax1.twinx()
ax2.plot(g1, prob1.reshape(101,101)[slice_ind], label = "Multimodal", color = 'red')
# ax2.plot(g1, prob2.reshape(101,101)[slice_ind], label = "Camelback", color = 'orange')
ax2.plot(g1, joint_prob[slice_ind], label = "Joint", color = 'purple', linestyle=':')
ax2.axhline(.2, color = 'gray',  linestyle='-', alpha = .2)
ax2.set_ylabel('predictive probability', color='r')
ax2.set_ylim(-.25, 3)
ax2.tick_params(axis='y', labelcolor = 'r')
ax2.set_yticks(np.arange(0, 1.25, .25))
# ax2.legend()
plt.title(str(0)+" samples from jCL")
# plt.title("0 samples from jCL")
filename = 'slice_mm1.pdf'
plt.savefig(filename)

plt.clf()
fig, ax1 = plt.subplots()
ax1.plot(g1, outcome_cb[slice_ind], label = 'True Camelback function', color = "black")
ax1.plot(g1, mu2_plot[slice_ind], label = 'GP prediction')
ax1.plot(.86, 0, marker = 'o', color = "purple", markersize = 6)
ax1.fill_between(g1, lower2[slice_ind], upper2[slice_ind], color='blue', alpha=0.2, label='Confidence Interval')
# ax1.fill_between(g1, -tol, tol, color='green', alpha = .2, label='Target value')
# ax1.axhline(0, color = 'green')
ax1.axhline(tol, color = 'green',  linestyle='--')
ax1.axhline(-tol, color = 'green',  linestyle='--')
ax1.set_ylabel('Camelback value', color='b')
ax1.set_xlabel('x1')
ax1.tick_params(axis='y', labelcolor = 'b')
ax1.set_ylim(-2,1)
# ax1.legend()
ax2 = ax1.twinx()
# ax2.plot(g1, prob1.reshape(101,101)[slice_ind], label = "Multimodal", color = 'red')
ax2.plot(g1, prob2.reshape(101,101)[slice_ind], label = "Camelback", color = 'orange')
ax2.plot(g1, joint_prob[slice_ind], label = "Joint", color = 'purple', linestyle=':')
ax2.axhline(.2, color = 'gray',  linestyle='-', alpha = .2)
ax2.set_ylabel('predictive probability', color='r')
ax2.set_ylim(-.25, 3)
ax2.tick_params(axis='y', labelcolor = 'r')
ax2.set_yticks(np.arange(0, 1.25, .25))
# ax2.legend()
plt.title(str(0)+" samples from jCL")
# plt.title("0 samples from jCL")
filename = 'slice_cb1.pdf'
plt.savefig(filename)



############# Second and Third Plots ##########################

# if we want to include any acquired points

indz_series = [8,21]

for indz in indz_series:

    train_X = np.loadtxt(file_name_x, delimiter=',')
    train_Y = np.loadtxt(file_name_y, delimiter=',')

    # see how the surfaces change 
    X = np.vstack((train_X, model[1:indz,0:d]))
    new_Y = mm_cb.mm_cb(model[1:indz,0:d])
    Y = np.vstack((train_Y, new_Y))

    gp1 = GP.GPyModel(X, Y[:,0].reshape(-1,1))
    gp1.nugbnd = [1e-16,1e-6]
    gp1.rand_restarts = 10
    gp1.Fit()
    mu1, var1 = gp1.predict(test_X)
    var1 = var1.reshape(-1,1)
    s1 = np.sqrt(var1).reshape(-1,1)

    gp2 = GP.GPyModel(X, Y[:,1].reshape(-1,1))
    gp2.nugbnd = [1e-16,1e-6]
    gp2.rand_restarts = 10
    gp2.Fit()
    mu2, var2 = gp2.predict(test_X)
    var2 = var2.reshape(-1,1)
    s2 = np.sqrt(var2).reshape(-1,1)

    mu1_plot = mu1.reshape(101,101)
    s1_plot = s1.reshape(101,101)

    mu2_plot = mu2.reshape(101,101)
    s2_plot = s2.reshape(101,101)

    limit = 0

    # if we want to include any acquired points
    tol = min(model[1:indz,d+1])
    prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
    prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)

    joint_prob = (prob1*prob2).reshape(101, 101)

    # 2D slice plot 

    lower1 = mu1_plot - 1.96*s1_plot
    upper1 = mu1_plot + 1.96*s1_plot

    lower2 = mu2_plot - 1.96*s2_plot
    upper2 = mu2_plot + 1.96*s2_plot


    slice_ind = 52

    # Two axes

    plt.clf()
    fig, ax1 = plt.subplots()
    ax1.plot(g1, outcome_mm[slice_ind], label = 'True Multimodal function', color = "black")
    ax1.plot(g1, mu1_plot[slice_ind], label = 'GP prediction')
    ax1.plot(.86, 0, marker = 'o', color = "purple", markersize = 6)
    ax1.fill_between(g1, lower1[slice_ind], upper1[slice_ind], color='blue', alpha=0.2, label='Confidence Interval')
    # ax1.fill_between(g1, -tol, tol, color='green', alpha = .2, label='Target value')
    # ax1.axhline(0, color = 'green')
    ax1.axhline(tol, color = 'green',  linestyle='--')
    ax1.axhline(-tol, color = 'green',  linestyle='--')
    ax1.set_ylabel('Multimodal value', color='b')
    ax1.set_xlabel('x1')
    ax1.tick_params(axis='y', labelcolor = 'b')
    ax1.set_ylim(-1.75,1)
    # ax1.legend()
    ax2 = ax1.twinx()
    ax2.plot(g1, prob1.reshape(101,101)[slice_ind], label = "Multimodal", color = 'red')
    # ax2.plot(g1, prob2.reshape(101,101)[slice_ind], label = "Camelback", color = 'orange')
    ax2.plot(g1, joint_prob[slice_ind], label = "Joint", color = 'purple', linestyle=':')
    ax2.axhline(.2, color = 'gray',  linestyle='-', alpha = .2)
    ax2.set_ylabel('predictive probability', color='r')
    ax2.set_ylim(-.25, 3)
    ax2.tick_params(axis='y', labelcolor = 'r')
    ax2.set_yticks(np.arange(0, 1.25, .25))
    # ax2.legend()
    plt.title(str(indz-1)+" samples from jCL")
    # plt.title("0 samples from jCL")
    filename = 'slice_mm'+str(indz)+'.pdf'
    plt.savefig(filename)

    plt.clf()
    fig, ax1 = plt.subplots()
    ax1.plot(g1, outcome_cb[slice_ind], label = 'True Camelback function', color = "black")
    ax1.plot(g1, mu2_plot[slice_ind], label = 'GP prediction')
    ax1.plot(.86, 0, marker = 'o', color = "purple", markersize = 6)
    ax1.fill_between(g1, lower2[slice_ind], upper2[slice_ind], color='blue', alpha=0.2, label='Confidence Interval')
    # ax1.fill_between(g1, -tol, tol, color='green', alpha = .2, label='Target value')
    # ax1.axhline(0, color = 'green')
    ax1.axhline(tol, color = 'green',  linestyle='--')
    ax1.axhline(-tol, color = 'green',  linestyle='--')
    ax1.set_ylabel('Camelback value', color='b')
    ax1.set_xlabel('x1')
    ax1.tick_params(axis='y', labelcolor = 'b')
    ax1.set_ylim(-2,1)
    # ax1.legend()
    ax2 = ax1.twinx()
    # ax2.plot(g1, prob1.reshape(101,101)[slice_ind], label = "Multimodal", color = 'red')
    ax2.plot(g1, prob2.reshape(101,101)[slice_ind], label = "Camelback", color = 'orange')
    ax2.plot(g1, joint_prob[slice_ind], label = "Joint", color = 'purple', linestyle=':')
    ax2.axhline(.2, color = 'gray',  linestyle='-', alpha = .2)
    ax2.set_ylabel('predictive probability', color='r')
    ax2.set_ylim(-.25, 3)
    ax2.tick_params(axis='y', labelcolor = 'r')
    ax2.set_yticks(np.arange(0, 1.25, .25))
    # ax2.legend()
    plt.title(str(indz-1)+" samples from jCL")
    # plt.title("0 samples from jCL")
    filename = 'slice_cb'+str(indz)+'.pdf'
    plt.savefig(filename)

# Figure 3: Demonstration of exploitation iterations --------------------------

### See Figures_R.R

# Figure 4: Tricands and Pareto front demonstration ---------------------------

### See Figures_R.R

# Figure 5: Simulation results ------------------------------------------------

### See Figures_R.R

