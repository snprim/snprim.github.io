#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 19 14:35:28 2023

@author: quinlan5
"""
import numpy as np
import copy as copy
import numpy.typing as npt
from scipy.linalg.lapack import get_lapack_funcs
from GPy.util.linalg import jitchol
from typing import List

# Gaussian process fitting package
import GPy
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

from numba import njit

(dpotri,) = get_lapack_funcs(("potri",), dtype="d")


@njit
def LHD_Random(N: int, k: int) -> npt.NDArray:
    """Generate a random Latin Hypercube Design

    Args:
        N (int): Number of Samples
        k (int): Number of Parameters

    Returns:
        npt.NDArray: Random LHD
    """

    X = np.zeros((N, k))
    vec1 = (np.linspace(1, N, N) - 0.5) / N
    for i in range(k):
        np.random.shuffle(vec1)
        X[:, i] = vec1
    return X


def PlotLOO(
    loopreds: npt.NDArray,
    loocov: npt.NDArray,
    X: npt.NDArray,
    Y: npt.NDArray,
    marginals: bool = False,
) -> None:
    """Generates Leave-One-Out Parity Plot

    Args:
        loopreds (npt.NDArray): leave-one-out mean predictions
        loocov (npt.NDArray): leave-one-out prediction variance
        X (npt.NDArray): Input data to the model
        Y (npt.NDArray): Output data
        marginals (bool, optional): Plot the leave-one-out for each input marginally. Defaults to False.

    """
    err1 = 1.959964 * np.sqrt(loocov)
    LOORMSE = np.sqrt(np.sum((loopreds - Y.flatten()) ** 2 / len(Y.flatten())))
    LOO_Coverage = np.sum(np.abs(loopreds.flatten() - Y.flatten()) < err1) / len(
        loopreds
    )
    _, ndims = X.shape

    def abline(a, b):
        ax = plt.gca()
        xmin, xmax = ax.get_xbound()
        ymax = a + b * (xmax)
        ymin = a + b * (xmin)
        l = mlines.Line2D([xmin, xmax], [ymin, ymax], color="k")
        ax.add_line(l)
        return l

    plt.figure()
    plt_txt_sizeB = 15
    plt_txt_sizeS = 16
    lbl = "95% Prediction Interval"
    with plt.style.context("seaborn-v0_8-whitegrid"):
        plt.plot(Y, loopreds, "ko")
        # plt.title( "Leave-one-out Prediction, Fidelity %i"  %fid,size =plt_txt_sizeB)
        plt.ylabel("Predicted", size=plt_txt_sizeS)
        plt.xlabel(
            "Observed \n LOO RMSE = %.2E, LOO Coverage = %.2f%%"
            % (LOORMSE, round(LOO_Coverage * 100, 4)),
            size=plt_txt_sizeS,
        )
        plt.errorbar(
            Y, loopreds, xerr=None, yerr=err1, ecolor="blue", ls="none", label=lbl
        )
        plt.legend()
        abline(0, 1)

    if marginals is True:
        with plt.style.context("seaborn-v0_8-whitegrid"):
            for i in range(ndims):
                plt.figure()
                plt.plot(X[:, i], Y.flatten() - loopreds, "ko")
                plt.title(
                    "Marginal Leave-one-out Prediction Input %i" % i, size=plt_txt_sizeB
                )
                plt.xlabel("Input", size=plt_txt_sizeS)
                plt.ylabel("Observed - Predicted", size=plt_txt_sizeS)


def initialize_gpy_kernel(kern_type, dims, l_bnds, g_bnds):
    k = dims
    if kern_type == "Matern5_2":
        k1 = GPy.kern.Matern52(1, active_dims=0, variance=1, ARD=False)
        temp_name = "Mat52_"
        kern_name = "Matern52"

    elif kern_type == "Matern3_2":
        k1 = GPy.kern.Matern32(1, active_dims=0, variance=1, ARD=False)
        temp_name = "Mat32_"
        kern_name = "Matern32"

    elif kern_type == "Gauss":
        k1 = GPy.kern.RBF(1, active_dims=0, variance=1, ARD=False)
        temp_name = "rbf_"
        kern_name = "RBF"

    else:
        raise ValueError(f"Unknown kernel type: {kern_type}")

    k1.variance.fix(1)
    k1.lengthscale.constrain_bounded(l_bnds[0], l_bnds[1], warning=False)

    for j in range(1, k):
        k1 = eval(
            "k1*GPy.kern." + kern_name + "(1,active_dims = j,variance = 1, ARD=False)"
        )
        eval("k1." + temp_name + str(j) + ".variance.fix(1, warning= False)")
        eval(
            "k1."
            + temp_name
            + str(j)
            + ".lengthscale.constrain_bounded("
            + str(l_bnds[0])
            + ","
            + str(l_bnds[1])
            + ",warning = False)"
        )

    k1 = k1 + GPy.kern.White(1)
    k1.white.variance.constrain_bounded(g_bnds[0], g_bnds[1], warning=False)
    k1 = GPy.kern.Bias(1) * (k1)

    return k1


class GPyModel:
    def __init__(self, X, Y, kern_type="Matern5_2"):
        self.X = X
        self.Y = Y
        self.Ytrain = np.copy(self.Y)
        self.samp_info = []
        self.kern_type = kern_type
        self.nugbnd = [1e-16, 0.1]
        self.lscalebnd = [1e-2, 10]
        self.varbnd = [1e-8, 1000]
        self.rand_restarts = 3
        self.max_iter = 1000
        self.verbose = False
        self.epsv = 1e-8
        self.Kchol = []
        self.Rinv = []
        self.normalize = True
        self.ndim = None
        self.model = None
        self.constmean = None
        self.sig = None
        self.nug = None
        self.likelihood = None
        self.H = None

    def Fit(self) -> None:
        """Fits the model parameters using GPy optimization"""
        N, self.ndim = self.X.shape

        if self.normalize == True:
            self.Ytrain = (self.Y - np.mean(self.Y)) / np.sqrt(np.var(self.Y, ddof=1))

        k1 = initialize_gpy_kernel(
            self.kern_type, self.ndim, self.lscalebnd, self.nugbnd
        )
        mf = GPy.mappings.Constant(self.ndim, 1)
        lik = GPy.likelihoods.Gaussian()
        lik.variance.fix(1e-16)
        GPfit = GPy.core.GP(
            self.X, self.Ytrain, likelihood=lik, kernel=k1, mean_function=mf
        )
        GPfit.optimize_restarts(
            num_restarts=self.rand_restarts,
            optimizer="lbfgs",
            messages=False,
            max_iters=self.max_iter,
            parallel=False,
            verbose=self.verbose,
        )

        self.model = GPfit
        self.constmean = self.model.constmap[0]
        par = self.Extract_params()
        self.sig = par[0]
        self.nug = par[1]
        self.likelihood = self.model.log_likelihood()
        Kmat_temp = copy.deepcopy(self.K(X=self.X))
        eps_temp = (self.epsv) * np.identity(N)
        nug_temp = self.nug * self.sig * np.identity(N)
        Rmat = Kmat_temp + eps_temp + nug_temp
        self.Kchol = np.copy(jitchol(Rmat))
        R_inv = dpotri(self.Kchol, lower=1)[0]
        self.Rinv = R_inv + (R_inv.T - np.diag(np.diagonal(R_inv)))
        self.H = np.ones(N)

    def Extract_params(self):
        _, k = self.X.shape
        scale_p = np.asarray(self.model.mul.bias.variance[0])
        lscale = np.zeros(k)
        if k == 1:
            lscale = self.model.mul.sum[1]
        if k > 1:
            lscale[0] = self.model.mul.sum.mul[1]
            for i in range(1, k):
                lscale[i] = self.model.mul.sum.mul[2 * i + 1]
        nugget = np.asarray(self.model.mul.sum.white.variance[0])
        params = np.concatenate((scale_p, nugget, lscale), axis=None)
        return params

    def K(self, X, X2=None):
        if self.ndim == 1:
            mod_name = self.model.mul.sum.parameter_names()[0].split(".")[0]
            return eval("self.model.mul.sum." + str(mod_name) + ".K(X,X2)*self.sig")

        if self.ndim > 1:
            return self.model.mul.sum.mul.K(X, X2) * self.sig

    def ModelInfo(self):
        # used to pass to cokriging model
        return [self.sig, self.nug, self.Kchol, self.Rinv, self.constmean, self.H]

    def summary(self):
        print("Model Fit Summary")
        print("Kernel Choice: " + self.kern_type)
        par = self.Extract_params()
        mean_val = self.constmean
        print("      Constant Mean:", mean_val)
        print("      Lengthscale:", par[2:])
        print("      Variance/Scale Hyperparameter:", par[0])
        print("      Nugget Value:", par[1])
        print("      Log-Likelihood:", self.likelihood)

    def predict(
        self, X: npt.NDArray, noiseless: bool = True, normalize: bool = True
    ) -> List[npt.NDArray]:
        """Generate predictions using GPy's predict call

        Args:
            X (npt.NDArray): Locations for new predictions
            noiseless (bool, optional): Generate predictions without the nugget if True. Defaults to True.
            normalize (bool, optional): Scale response back to original scale. Defaults to True.

        Returns:
            List[npt.NDArray]: prediction mean and prediction variance
        """
        include_likelihood = not noiseless

        ypred, covpred = self.model.predict(X, include_likelihood=include_likelihood)

        if normalize == True:
            normalize = self.normalize

        if normalize:
            y_std = np.sqrt(np.var(self.Y, ddof=1))
            y_mean = np.mean(self.Y)
            ypred = ypred * y_std + y_mean
            covpred = covpred * (y_std**2)

        return [ypred, covpred]

    def LOOpredict(self, plots=True, marginals=False):
        N, _ = self.X.shape
        Ki_val = self.Rinv * self.sig
        Ki_val = Ki_val - np.dot(
            np.sum(Ki_val, axis=1).reshape(-1, 1),
            np.sum(Ki_val, axis=1).reshape(1, N) / np.sum(Ki_val),
        )

        sdloo = self.sig * (self.nug + (1 / (np.diagonal(Ki_val).flatten()) - self.nug))
        matrix2 = (self.Ytrain.flatten() - self.constmean).reshape(-1, 1)
        mat_second = np.matmul(Ki_val, matrix2)
        yloo = (
            self.Ytrain.flatten()
            - (mat_second.flatten() / np.diagonal(Ki_val).flatten()).flatten()
        )
        if self.normalize == True:
            sdloo *= np.var(self.Y, ddof=1)
            yloo *= np.sqrt(np.var(self.Y, ddof=1))
            yloo += np.mean(self.Y)

        loopreds = yloo
        loocov = sdloo
        if plots == True:
            PlotLOO(loopreds, loocov, self.X, self.Y, marginals)

        return [yloo, sdloo]
