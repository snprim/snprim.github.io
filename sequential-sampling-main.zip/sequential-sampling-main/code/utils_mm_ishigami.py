import numpy as np
from pyDOE import lhs
from scipy.stats import norm
from scipy.optimize import minimize
import warnings
warnings.filterwarnings(action = "ignore", category = RuntimeWarning)
from GP import GPyModelEasy as GP
from scipy.optimize import minimize

def scale_up(x, bounds):
    d = x.shape[1]
    y = np.zeros(shape=x.shape)
    for i in range(0, d):
        y[:,i] = x[:,i] * (bounds[1, i] - bounds[0, i]) + bounds[0, i]
    return y

def scale_down(x, bounds):
    d = x.shape[1]
    y = np.zeros(shape=x.shape)
    for i in range(0, d):
        y[:,i] = (x[:,i] - bounds[0, i]) / (bounds[1, i] - bounds[0, i])
    return y

def mm_threeD(xx):
    return (np.power(xx[:,0],2)+4)*(xx[:,1]-1)/20 - np.sin(5*xx[:,0]/2) - 2 + xx[:,2]

def ishigami_threeD(xx):
    contour = 10
    a = 7
    b = 0.1
    return np.sin(xx[:,0]) + a*np.power(np.sin(xx[:,1]),2) + b*np.power(xx[:,2],4)*np.sin(xx[:,0]) - contour

def Y3_threeD(xx):
    return np.sin(xx[:,0]) + np.cos(xx[:,0]) + np.power(xx[:,1], 2) + np.sqrt(xx[:,2]) + np.sin(xx[:,2]) - 2
 
def mm_ishigami(xx):
    bounds_mm = np.array([[-4,-3,0],[7,8,1]])
    bounds_ishi = np.array([[-np.pi,-np.pi, -np.pi],[np.pi,np.pi, np.pi]])
    covariates_mm = scale_up(xx, bounds_mm)
    covariates_ishi = scale_up(xx, bounds_ishi)
    outcomes_mm = (mm_threeD(covariates_mm) - 5.2352e-4) / 3.588
    outcomes_ishi = (ishigami_threeD(covariates_ishi)+12.79921514) / 3.720
    outcomes_Y3 = (Y3_threeD(xx)-1.05174287) / 0.582
    return np.column_stack((outcomes_mm, outcomes_ishi, outcomes_Y3))

def neg_joint_prob_function(x, gp1, gp2, gp3, tol, limit):
    x1 , x2, x3 = x
    new = np.array([[x1, x2, x3]])
    pred1, var1 = gp1.predict(new)
    s1 = np.sqrt(var1)
    pred2, var2 = gp2.predict(new)
    s2 = np.sqrt(var2)
    pred3, var3 = gp3.predict(new)
    s3 = np.sqrt(var3)
    
    prob1 = norm.cdf((pred1 - limit + tol) / s1) - norm.cdf((pred1 - limit - tol) / s1)
    prob2 = norm.cdf((pred2 - limit + tol) / s2) - norm.cdf((pred2 - limit - tol) / s2)
    prob3 = norm.cdf((pred3 - limit + tol) / s3) - norm.cdf((pred3 - limit - tol) / s3)
    return -(prob1*prob2*prob3)

# optimize using log prob
def neg_joint_prob_function_new(x, gp1, gp2, gp3, tol, limit):
    x1 , x2, x3 = x
    new = np.array([[x1, x2, x3]])
    pred1, var1 = gp1.predict(new)
    s1 = np.sqrt(var1)
    pred2, var2 = gp2.predict(new)
    s2 = np.sqrt(var2)
    pred3, var3 = gp3.predict(new)
    s3 = np.sqrt(var3)
    
    z1p = (pred1 - limit + tol) / s1
    z1n = (pred1 - limit - tol) / s1
    z2p = (pred2 - limit + tol) / s2
    z2n = (pred2 - limit - tol) / s2
    z3p = (pred3 - limit + tol) / s3
    z3n = (pred3 - limit - tol) / s3
    log_p1p = np.max((np.vstack((np.abs(norm.logcdf(z1p)), 1e-10))))*-1
    log_p1n = np.max((np.vstack((np.abs(norm.logcdf(z1n)), 2e-10))))*-1
    log_prob1 = log_p1p + np.log1p(-np.exp(log_p1n - log_p1p))
    log_p2p = np.max((np.vstack((np.abs(norm.logcdf(z2p)), 1e-10))))*-1
    log_p2n = np.max((np.vstack((np.abs(norm.logcdf(z2n)), 2e-10))))*-1
    log_prob2 = log_p2p + np.log1p(-np.exp(log_p2n - log_p2p))
    log_p3p = np.max((np.vstack((np.abs(norm.logcdf(z3p)), 1e-10))))*-1
    log_p3n = np.max((np.vstack((np.abs(norm.logcdf(z3n)), 2e-10))))*-1
    log_prob3 = log_p3p + np.log1p(-np.exp(log_p3n - log_p3p))
    return -(log_prob1 + log_prob2 + log_prob3)

def opt_joint_prob(gp1, gp2, gp3, tol, lowest):
    d = gp1.ndim
    nmulti = 10*d
    ran_starts = np.random.rand(nmulti, d)
    ran_starts = np.vstack((ran_starts, lowest))
    joint_results = []
    joint_val = []
    for start in range(nmulti+1):
        opt_joint = minimize(neg_joint_prob_function_new, ran_starts[start], method = "L-BFGS-B", bounds=((0,1),(0,1),(0,1)), args = (gp1, gp2, gp3, tol, 0))
        joint_results.append((opt_joint.x))
        joint_val.append((opt_joint.fun))
    x1, x2, x3 = joint_results[np.argpartition(joint_val,2)[:1][0]]    
    new_X = np.array([[x1, x2, x3]])
    lowest_prob = min(joint_val)       
    print(joint_val)
    print(lowest_prob)       
    return (new_X, lowest_prob)

def neg_entropy(x, gp, limit):
    d = gp.ndim
    if len(x.shape) == 1: 
        x = x.reshape(1, d)
    mu, var = gp.predict(x)
    std = np.sqrt(var).reshape(-1,1)
    fail_prob = norm.cdf((mu - limit) / std)
    ent = -(1 - fail_prob) * np.log(1 - fail_prob) - fail_prob * np.log(fail_prob)
    ent[np.isnan(ent)] = 0
    return -ent

def opt_alt_cole(gp):
    d = gp.ndim
    xbatch = lhs(d, 10 * d) 
    best_batch = np.argmin(neg_entropy(xbatch, gp, 0))
    xinit = xbatch[best_batch, :]
    opt_pt = minimize(neg_entropy, x0 = xinit, method = "L-BFGS-B", bounds=((0,1),(0,1),(0,1)), args = (gp, 0))       
    x1, x2, x3 = opt_pt.x
    return np.array([[x1, x2, x3]])

def entropy(mu, std, limit):
    if len(mu.shape) == 1: 
        mu = mu.reshape(-1, 1)
    if len(std.shape) == 1:
        std = std.reshape(-1, 1)
    fail_prob = norm.cdf((mu - limit) / std)
    ent = -(1 - fail_prob) * np.log(1 - fail_prob) - fail_prob * np.log(fail_prob)
    ent[np.isnan(ent)] = 0
    return ent