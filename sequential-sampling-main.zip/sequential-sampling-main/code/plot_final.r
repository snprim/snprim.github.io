setwd("/g/g16/prim3/sequential-sampling/code")
library(tidyverse)

### Make result plots for all functions

funcz <- c("dg", "mm_cb", "mm_ishigami")
for (func in funcz){
    reps <- 50
    if (func == "dg" | func == "mm_cb"){
        n0 <- 5
        budget <- 20
        d <- 2
    }
    if (func == "mm_ishigami"){
        n0 <- 10
        budget <- 30
        d <- 3
        func_name <- "multimodal-ishigami-linear"
    }
    if (func == "dg") func_name <- "double gramacy"
    if (func == "mm_cb") func_name <- "multimodal-camelback"

    alt_entropy <- alt_pareto <- joint_pareto <- array(NA, c(reps, budget+1, d+4))
    methods <- c("alt_entropy", "alt_pareto", "joint_pareto")
    for (i in 1:reps){
        for (method in methods){
            seed <- i-1
            res <- read_csv(paste0("result/", func, "_", method, "_final_seed", seed, ".csv"), col_names = F)
            if (method == "alt_entropy") alt_entropy[i,,] <- as.matrix(res)
            else if(method == "alt_pareto") alt_pareto[i,,] <- as.matrix(res)
            else if(method == "joint_pareto") joint_pareto[i,,] <- as.matrix(res)
        }
    }

    lhs <- array(NA, c(reps, budget+1, d+1))
    for (i in 1:reps){
    seed <- i-1
    res <- read_csv(paste0("result/", func, "_lhs_final_seed", seed, ".csv"), col_names = F)
    lhs[i,,] <- as.matrix(res[(n0+1):(n0+budget+1),])
    }

    # min_dist: col d+1
    # save the original
    joint_pareto_original <- joint_pareto
    alt_entropy_original <- alt_entropy
    alt_pareto_original <- alt_pareto

    # Find the last non-NA value in each row
    last_non_na_joint_pareto <- apply(joint_pareto[,,(d+1)], 1, function(row) tail(na.omit(row), 1))
    last_non_na_alt_entropy <- apply(alt_entropy[,,(d+1)], 1, function(row) tail(na.omit(row), 1))
    last_non_na_alt_pareto <- apply(alt_pareto[,,(d+1)], 1, function(row) tail(na.omit(row), 1))

    # fill in NaN with the last non NaN value for each iteration
    for (i in 1:reps){
    joint_pareto[i,is.nan(joint_pareto[i,,(d+1)]),(d+1)] <- last_non_na_joint_pareto[i]
    alt_entropy[i,is.nan(alt_entropy[i,,(d+1)]),(d+1)] <- last_non_na_alt_entropy[i]
    alt_pareto[i,is.nan(alt_pareto[i,,(d+1)]),(d+1)] <- last_non_na_alt_pareto[i]
    }

    # set lower bound as 1e-3
    joint_pareto_original2 <- joint_pareto
    alt_entropy_original2 <- alt_entropy
    alt_pareto_original2 <- alt_pareto

    joint_pareto[,,(d+1)] <- ifelse(joint_pareto[,,(d+1)] < 1e-3, 1e-3, joint_pareto[,,(d+1)])
    alt_entropy[,,(d+1)] <- ifelse(alt_entropy[,,(d+1)] < 1e-3, 1e-3, alt_entropy[,,(d+1)])
    alt_pareto[,,(d+1)] <- ifelse(alt_pareto[,,(d+1)] < 1e-3, 1e-3, alt_pareto[,,(d+1)])

    method_list <- c("alt_entropy", "alt_pareto", "lhs", "joint_pareto")

    min_dist <- list()
    for (i in 1:length(method_list)){
        res_method <- eval(parse(text=paste0(method_list[i])))
        min_dist[[i]] <- matrix(NA, nrow = budget+1, ncol = 5)
        colnames(min_dist[[i]]) <- c("number", "median", "upper", "lower", "method")
        min_dist[[i]] <- as.data.frame(min_dist[[i]])
        min_dist[[i]]$number <- (n0):(n0+budget)
        min_dist[[i]]$median <- apply(res_method[,,(d+1)], MARGIN = 2, median)
        min_dist[[i]]$upper <- apply(res_method[,,(d+1)], MARGIN = 2, FUN = quantile, probs = .9)
        min_dist[[i]]$lower <- apply(res_method[,,(d+1)], MARGIN = 2, FUN = quantile, probs = .1)
        min_dist[[i]]$method <- method_list[i]
    }

    min_dist_all <- rbind(min_dist[[1]], min_dist[[2]], min_dist[[3]], min_dist[[4]])

    png(filename = paste0("plot_final/min_dist_", func, "_final.png"))
    plot <- ggplot(min_dist_all, aes(x = number, y = median, color = method,fill = method)) +
    geom_line(aes(linetype = method)) +  # Add lines with custom thickness
    labs(
        title = paste0(func_name),
        x = "Number of Total Samples",
        y = "Distance (log scale)",
        color = "Sampling Method",
        fill = "Sampling Method",
        linetype = "Sampling Method"
    ) +
    scale_y_log10() +
    geom_ribbon(aes(ymin = lower, ymax = upper, linetype = method), size = .5, alpha = 0.2) +
    theme(
        plot.title = element_text(hjust = 0.5, face = "bold", size = 16),  # Center and bold the title
        axis.title = element_text(face = "bold"),  # Bold axis labels
        legend.position = "top",  # Position legend at the top
        legend.title = element_text(face = "bold")  # Bold legend title
    ) +
    scale_linetype_manual(values = c("joint_pareto" = "solid", "alt_entropy" = "dashed", "alt_pareto" = "dotted", "lhs" = "dotdash")) +
    scale_fill_viridis_d() + 
    scale_color_viridis_d() 
    print(plot)
    dev.off()
    
}

res <- read_csv(paste0("result/", "mm_cb", "_", "joint_pareto", "_final_seed", 39, ".csv"), col_names = F)

text <- res$X3[1]
# Remove the first "X"
step1 <- sub("^X", "", text)
# Change the second "." into "-"
step2 <- sub("(\\.[^\\.]+)\\.", "\\1-", step1)
step3 <- as.numeric(step2)

## Make three plots in the same place ##

### Make result plots for all functions
r <- 1
plotz <- list()
funcz <- c("dg", "mm_cb", "mm_ishigami")
for (func in funcz){
    reps <- 50
    if (func == "dg" | func == "mm_cb"){
        n0 <- 5
        budget <- 20
        d <- 2
    }
    if (func == "mm_ishigami"){
        n0 <- 10
        budget <- 30
        d <- 3
        func_name <- "3D: Multimodal-Ishigami-Trig"
    }
    if (func == "dg") func_name <- "2D: Double Gramacy"
    if (func == "mm_cb") func_name <- "2D: Multimodal-Camelback"

    alt_entropy <- alt_pareto <- joint_pareto <- array(NA, c(reps, budget+1, d+4))
    methods <- c("alt_entropy", "alt_pareto", "joint_pareto")
    for (i in 1:reps){
        for (method in methods){
            seed <- i-1
            res <- read_csv(paste0("result/", func, "_", method, "_final_seed", seed, ".csv"), col_names = F)
            if (is.character(res$X3[1]) & func == "mm_cb"){
                text <- res$X3[1]
                # Remove the first "X"
                step1 <- sub("^X", "", text)
                # Change the second "." into "-"
                step2 <- sub("(\\.[^\\.]+)\\.", "\\1-", step1)
                res$X3[1] <- as.numeric(step2)
                res$X3 <- as.numeric(res$X3)
                text <- res$X4[1]
                # Remove the first "X"
                step1 <- sub("^X", "", text)
                # Change the second "." into "-"
                step2 <- sub("(\\.[^\\.]+)\\.", "\\1-", step1)
                res$X4[1] <- as.numeric(step2)
                res$X4 <- as.numeric(res$X4)
                res$X1[1] <- res$X2[1] <- res$X5[1] <- res$X6[1] <- NA
                res$X1 <- as.numeric(res$X1)
                res$X2 <- as.numeric(res$X2)
                res$X5 <- as.numeric(res$X5)
                res$X6 <- as.numeric(res$X6)
            }
            if (is.character(res$X3[1]) & func == "mm_ishigami"){
                text <- res$X4[1]
                # Remove the first "X"
                step1 <- sub("^X", "", text)
                # Change the second "." into "-"
                step2 <- sub("(\\.[^\\.]+)\\.", "\\1-", step1)
                res$X4[1] <- as.numeric(step2)
                res$X4 <- as.numeric(res$X4)
                text <- res$X5[1]
                # Remove the first "X"
                step1 <- sub("^X", "", text)
                # Change the second "." into "-"
                step2 <- sub("(\\.[^\\.]+)\\.", "\\1-", step1)
                res$X5[1] <- as.numeric(step2)
                res$X5 <- as.numeric(res$X5)
                res$X1[1] <- res$X2[1] <- res$X3[1] <- res$X6[1] <- res$X6[1] <- NA
                res$X1 <- as.numeric(res$X1)
                res$X2 <- as.numeric(res$X2)
                res$X3 <- as.numeric(res$X3)
                res$X6 <- as.numeric(res$X6)
                res$X7 <- as.numeric(res$X7)
            }

            if (method == "alt_entropy") alt_entropy[i,,] <- as.matrix(res)
            else if(method == "alt_pareto") alt_pareto[i,,] <- as.matrix(res)
            else if(method == "joint_pareto") joint_pareto[i,,] <- as.matrix(res)
        }
    }

    lhs <- array(NA, c(reps, budget+1, d+1))
    for (i in 1:reps){
    seed <- i-1
    res <- read_csv(paste0("result/", func, "_lhs_final_seed", seed, ".csv"), col_names = F)
    lhs[i,,] <- as.matrix(res[(n0+1):(n0+budget+1),])
    }

    joint_pareto[is.na(joint_pareto)] <- NA

    # min_dist: col d+1
    # save the original
    joint_pareto_original <- joint_pareto
    alt_entropy_original <- alt_entropy
    alt_pareto_original <- alt_pareto

    # Find the last non-NA value in each row
    last_non_na_joint_pareto <- apply(joint_pareto[,,(d+1)], 1, function(row) tail(na.omit(row), 1))
    last_non_na_alt_entropy <- apply(alt_entropy[,,(d+1)], 1, function(row) tail(na.omit(row), 1))
    last_non_na_alt_pareto <- apply(alt_pareto[,,(d+1)], 1, function(row) tail(na.omit(row), 1))

    # fill in NaN with the last non NaN value for each iteration
    for (i in 1:reps){
    joint_pareto[i,is.na(joint_pareto[i,,(d+1)]),(d+1)] <- last_non_na_joint_pareto[i]
    alt_entropy[i,is.na(alt_entropy[i,,(d+1)]),(d+1)] <- last_non_na_alt_entropy[i]
    alt_pareto[i,is.na(alt_pareto[i,,(d+1)]),(d+1)] <- last_non_na_alt_pareto[i]
    }

    # set lower bound as 1e-3   
    joint_pareto_original2 <- joint_pareto
    alt_entropy_original2 <- alt_entropy
    alt_pareto_original2 <- alt_pareto

    joint_pareto[,,(d+1)] <- ifelse(joint_pareto[,,(d+1)] < 1e-3, 1e-3, joint_pareto[,,(d+1)])
    alt_entropy[,,(d+1)] <- ifelse(alt_entropy[,,(d+1)] < 1e-3, 1e-3, alt_entropy[,,(d+1)])
    alt_pareto[,,(d+1)] <- ifelse(alt_pareto[,,(d+1)] < 1e-3, 1e-3, alt_pareto[,,(d+1)])

    method_list <- c("alt_entropy", "alt_pareto", "joint_pareto", "lhs")

    min_dist <- list()
    for (i in 1:length(method_list)){
        if (i < 4) {
            res_method <- eval(parse(text=paste0(method_list[i])))
            min_dist[[i]] <- matrix(NA, nrow = budget+1, ncol = 5)
            colnames(min_dist[[i]]) <- c("number", "median", "upper", "lower", "method")
            min_dist[[i]] <- as.data.frame(min_dist[[i]])
            min_dist[[i]]$number <- (n0):(n0+budget)
            min_dist[[i]]$median <- apply(res_method[,,(d+1)], MARGIN = 2, median)
            min_dist[[i]]$upper <- apply(res_method[,,(d+1)], MARGIN = 2, FUN = quantile, probs = .9)
            min_dist[[i]]$lower <- apply(res_method[,,(d+1)], MARGIN = 2, FUN = quantile, probs = .1)
            min_dist[[i]]$method <- method_list[i]
        }
        else if (i == 4) {
            res_method <- eval(parse(text=paste0(method_list[i])))
            min_dist[[i]] <- matrix(NA, nrow = budget+1, ncol = 5)
            colnames(min_dist[[i]]) <- c("number", "median", "upper", "lower", "method")
            min_dist[[i]] <- as.data.frame(min_dist[[i]])
            min_dist[[i]]$number <- (n0):(n0+budget)
            min_dist[[i]]$median <- apply(res_method[,,(1)], MARGIN = 2, median)
            min_dist[[i]]$upper <- apply(res_method[,,(1)], MARGIN = 2, FUN = quantile, probs = .9)
            min_dist[[i]]$lower <- apply(res_method[,,(1)], MARGIN = 2, FUN = quantile, probs = .1)
            min_dist[[i]]$method <- method_list[i]
        }
    }

    # combine all
    min_dist_all <- rbind(min_dist[[1]], min_dist[[2]], min_dist[[3]], min_dist[[4]])

    min_dist_all$method <- factor(min_dist_all$method,
                      levels = c("alt_entropy", "alt_pareto", "joint_pareto", "lhs"),
                      labels = c("Alt. Entropy", "Alt. Pareto", "jCL", "LHS"))

    # save plots in a list to put them in the same plot later
    # png(filename = paste0("plot_final/min_dist_", func, "_final.png"))
    plotz[[r]] <- ggplot(min_dist_all, aes(x = number, y = median, color = method,fill = method)) +
    geom_line(aes(linetype = method)) +  # Add lines with custom thickness
    labs(
        title = paste0(func_name),
        # x = "Number of Total Samples",
        # y = "Distance (log scale)",
        x = "",
        y = "",
        color = "Sampling Method",
        fill = "Sampling Method",
        linetype = "Sampling Method"
    ) +
    scale_y_log10() +
    geom_ribbon(aes(ymin = lower, ymax = upper, linetype = method), size = .5, alpha = 0.2) +
    theme_bw() +
    theme(
        plot.title = element_text(hjust = 0.5, face = "bold", size = 16),  # Center and bold the title
        axis.title = element_text(face = "bold"),  # Bold axis labels
        legend.position = "top",  # Position legend at the top
        legend.title = element_text(face = "bold", size = 16),  # Bold legend title
        legend.text = element_text(size = 16),
        axis.text.x  = element_text(size = 16),    
        axis.text.y  = element_text(size = 16)     
        # panel.background = element_rect(fill = "white",
        #                        colour = "white",
        #                         size = 0.5, linetype = "solid"),
        # panel.grid.major = element_line(color = "lightgrey"),
        # panel.grid.minor = element_line(color = "lightgrey") 
    ) +
    scale_linetype_manual(values = c("jCL" = "solid", "Alt. Entropy" = "dashed", "Alt. Pareto" = "dotted", "LHS" = "dotdash")) +
    scale_fill_viridis_d() + 
    scale_color_viridis_d() 
    # print(plot)
    # dev.off()
    
    r = r + 1
}


library(ggpubr)

# png(filename = paste0("../../../sequential-sampling/joint_paper/images/sim_result.png"), width = 800, height = 300)
# result_all <- ggarrange(plotz[[2]], plotz[[1]], plotz[[3]], nrow = 1, common.legend = TRUE, hjust = -1)
# annotate_figure(result_all,
#         left = text_grob("Distance (log scale)", rot = 90),
#         bottom = text_grob("Number of Total Sample"))
# dev.off()

pdf(paste0("../../sequential-sampling/joint_paper/images/sim_result.pdf"), width = 14, height = 5)
result_all <- ggarrange(plotz[[2]], plotz[[1]], plotz[[3]], nrow = 1, common.legend = TRUE, hjust = -1)
annotate_figure(result_all,
        # left = text_grob(expression(D[n]), rot = 90, size = 16),
        bottom = text_grob("Number of Total Samples", size = 18, face="bold"))
dev.off()

