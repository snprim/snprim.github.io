import rpy2.robjects as robjects
import numpy as np
from scipy.stats import norm
import warnings
warnings.filterwarnings(action = "ignore", category = RuntimeWarning)

robjects.r('''
library(deepgp)
xbest <- matrix(c(0.3, 0.34), nrow = 1)

dist_pred <- function(x, fit1, fit2) { 
    # hard-coded limit of zero
    if (!is.matrix(x)) x <- matrix(x, nrow = 1)
    pred1 <- predict(fit1, x)$mean
    pred2 <- predict(fit2, x)$mean
    return(sqrt((pred1 - 0)^2 + (pred2 - 0)^2))
}

find_best <- function(fit1, fit2, lowest) {
    d <- ncol(fit1$x)
    nmulti <- 10
    lowest <- matrix(lowest, nrow = 1)
    xinit <- matrix(runif(d *(nmulti-nrow(lowest))), ncol = d)
    xinit <- rbind(xinit, lowest) # always include best point

    par <- matrix(NA, nrow = nmulti, ncol = d)
    value <- rep(NA, times = nmulti)
    for (i in 1:nmulti) {
        opt <- optim(xinit[i, ], dist_pred, method = "L-BFGS-B", lower = c(0, 0), upper = c(1, 1), fit1 = fit1, fit2 = fit2)
        par[i, ] <- opt$par
        value[i] <- opt$value
    }
    out <- list(lowest = par[which.min(value), ], min_dist = min(value))
    return(out)
}
           
neg_joint_prob <- function(x, fit1, fit2, tol) {
  if (!is.matrix(x)) x <- matrix(x, nrow = 1)
  pred1 <- predict(fit1, x)
  prob1 <- pnorm(0 + tol, pred1$mean, sqrt(pred1$s2)) - pnorm(0 - tol, pred1$mean, sqrt(pred1$s2))
  pred2 <- predict(fit2, x)
  prob2 <- pnorm(0 + tol, pred2$mean, sqrt(pred2$s2)) - pnorm(0 - tol, pred2$mean, sqrt(pred2$s2))
  return(-prob1*prob2)
}

# optimize using log prob
neg_joint_prob_new <- function(x, fit1, fit2, tol) {
  limit <- 0 
           
  if (!is.matrix(x)) x <- matrix(x, nrow = 1)
  pred1 <- predict(fit1, x)
  pred2 <- predict(fit2, x)

  # Assuming predict returns a list with mean and variance
  mu1 <- pred1$mean
  var1 <- pred1$s2
  s1 <- sqrt(var1)
  
  mu2 <- pred2$mean
  var2 <- pred2$s2
  s2 <- sqrt(var2)
  
  # Calculate z-scores
  z1p <- (mu1 - limit + tol) / s1
  z1n <- (mu1 - limit - tol) / s1
  z2p <- (mu2 - limit + tol) / s2
  z2n <- (mu2 - limit - tol) / s2
  
  # Log CDFs
  log_p1p <- max(abs(pnorm(z1p, log.p=TRUE)), 1e-10) * -1
  log_p1n <- max(abs(pnorm(z1n, log.p=TRUE)), 2e-10) * -1
  log_prob1 <- log_p1p + log1p(-exp(log_p1n - log_p1p))
  
  log_p2p <- max(abs(pnorm(z2p, log.p=TRUE)), 1e-10) * -1
  log_p2n <- max(abs(pnorm(z2n, log.p=TRUE)), 2e-10) * -1
  log_prob2 <- log_p2p + log1p(-exp(log_p2n - log_p2p))
  
  return (-(log_prob1 + log_prob2))
}
           
opt_joint_prob <- function(fit1, fit2, tol, lowest) {
  d <- ncol(fit1$x)
  nmulti <- 10
  xinit <- matrix(runif(d *nmulti), ncol = d)
  xinit <- rbind(xinit, lowest) # always include best point
  par <- matrix(NA, nrow = nmulti+1, ncol = d)
  value <- rep(NA, times = nmulti+1)
  for (i in 1:(nmulti+1)) {
    opt <- optim(xinit[i, ], neg_joint_prob_new, method = "L-BFGS-B", lower = c(0, 0),
                 upper = c(1, 1), fit1 = fit1, fit2 = fit2, tol = tol)
    par[i, ] <- opt$par
    value[i] <- opt$value
  }
  out <- list(best = par[which.min(value), , drop = FALSE], prob = min(value))
  return(out)
}
           
neg_ent <- function(x, fit) {  
  if (!is.matrix(x)) x <- matrix(x, nrow = 1)       
  pred <- predict(fit, x)
  mu <- pred$mean
  sig2 <- pred$s2
  limit <- 0
  fail_prob <- pnorm((mu - limit)/sqrt(sig2))
  ent <- -(1 - fail_prob) * log(1 - fail_prob) - fail_prob * 
        log(fail_prob) 
  ent[which(is.nan(ent))] <- 0
  return(-ent)
}

opt_ent <- function(fit) {
  d <- ncol(fit$x)
  xbatch <- matrix(lhs::randomLHS(n=10*d, k=d), ncol = d)
  xinit <- xbatch[which.min(neg_ent(xbatch, fit)),]
  opt <- optim(xinit, neg_ent, method = "L-BFGS-B", lower = c(0, 0), upper = c(1, 1), fit = fit)
  return(matrix(opt$par, nrow = 1))
}
''')

def scale_up(x, bounds):
    d = x.shape[1]
    y = np.zeros(shape=x.shape)
    for i in range(0, d):
        y[:,i] = x[:,i] * (bounds[1, i] - bounds[0, i]) + bounds[0, i]
    return y

def gramacy1(xx):
    return xx[:,0] * np.exp(-np.power(xx[:,0]-.5,2)-np.power(xx[:,1]+.5,2))-0.1

def gramacy2(xx):
    return (xx[:,1]+.5)*np.exp(-np.power(xx[:,1]/4,2)-np.power(xx[:,0],2))-1

def double_gram(xx):
    bounds_gram1 = np.array([[-2,-2],[6,6]])
    bounds_gram2 = np.array([[-2,-2],[6,6]])
    covariates_gram1 = scale_up(xx, bounds_gram1)
    covariates_gram2 = scale_up(xx, bounds_gram2)
    outcomes_gram1 = gramacy1(covariates_gram1)*9.27 + 0.09830494
    outcomes_gram2 = gramacy2(covariates_gram2)/0.4975 - 0.01300846
    return np.column_stack((outcomes_gram1, outcomes_gram2))
