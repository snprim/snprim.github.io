setwd("C:/Users/shihn/Documents/joint-contours/shihni_code")

library(latex2exp) # for figure labels
library(viridis) # for heatmap colors
library(tidyverse)
# library(deepgp)

source("functions.R")
source("tricands.R")


get_pareto <- function(var1, var2) {
  # Order observations based on the first variable
  o <- order(var1, decreasing = TRUE)
  var2 <- var2[o]
  skyline <- c(1)
  # Add lesser rows only if they win in the second variable
  for (i in 2:length(var1)) {
    if (all(var2[i] > var2[(i - 1):1]))
      skyline <- append(skyline, i)
  }
  # Return un-ordered indices
  return(o[skyline])
}

# Figures 1 and 6: Heatmaps of Multimodal-Camelback and Double-Gramacy -------

# mm_cb ----------------------------------------------------------------------

breaks1 <- seq(-3.28, 4.93, length = 129)
breaks2 <- seq(-2.82, 1.05, length = 129)

# Set up ----------------------------------------------------------------------

grid <- seq(0, 1, length = 225) # denser grid for prettier plots
xp <- as.matrix(expand.grid(grid, grid))
yp1 <- multimodal(xp)
yp2 <- camel(xp)

xbest = matrix(c(0.86, 0.52),nrow=1)
multimodal(xbest)
camel(xbest)

lhs_point <- read_csv('../code/x_mm_cb_0.csv', col_names =FALSE)
# the columns in the result: (acquired point x1, x2), min dist, tol, lowest_prob, a number that indicates algorithm stops there
joint_point <- read_csv("../code/mm_cb_joint_pareto_final_seed0.csv", col_names = FALSE)
joint_point$type <- ifelse(is.nan(joint_point$X5), "exploration", "exploitation")
joint_point$shape <- ifelse(is.nan(joint_point$X5), 15, 17)
n <- nrow(joint_point)

pdf("figures/mm_cb_surface.pdf", width = 9, height = 5)
par(mfrow = c(1, 2), mar = c(3, 3, 3, 1), xpd = TRUE)
image(grid, grid, matrix(yp1, nrow = length(grid)), col = viridis(128),
      xlab = "", ylab = "", main = "Multimodal",
      xaxt = "n", yaxt = "n", breaks = breaks1, cex.main = 1.2)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
contour(grid, grid, matrix(yp1, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lwd = 2)
contour(grid, grid, matrix(yp2, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lty = 2, lwd = 2)
points(lhs_point, col = alpha("white", 0.8), pch = 16, cex = 1.2)
points(joint_point$X1[2:n], joint_point$X2[2:n], col = alpha("cyan", .8), pch = joint_point$shape[2:n], cex = 1.2)
points(xbest, col = alpha("red", .8), pch = 17, cex = 1.5)
image(grid, grid, matrix(yp2, nrow = length(grid)), col = viridis(128),
      xlab = "", ylab = "", main = "Camelback",
      xaxt = "n", yaxt = "n", breaks = breaks2, cex.main = 1.2)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
contour(grid, grid, matrix(yp1, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lty = 2, lwd = 2)
contour(grid, grid, matrix(yp2, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lwd = 2)
points(lhs_point, col = alpha("white", .8), pch = 16, cex = 1.2)
# points(joint_point$X1, joint_point$X2, col = alpha("cyan",.8), pch = 15, cex = 1.2)
points(joint_point$X1[2:n], joint_point$X2[2:n], col = alpha("cyan", .8), pch = joint_point$shape[2:n], cex = 1.2)
points(xbest, col = alpha("red",.8), pch = 17, cex = 1.5)
axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
dev.off()


# double-gramacy ----------------------------------------------------------------------

breaks1 <- seq(-2.54, 6.4, length = 129)
breaks2 <- seq(-4.38, 2.07, length = 129)

grid <- seq(0, 1, length = 225) # denser grid for prettier plots
xp <- as.matrix(expand.grid(grid, grid))
yp1 <- gramacy1(xp)
yp2 <- gramacy2(xp)

xbest = matrix(c(0.3, 0.34),nrow=1)
gramacy1(xbest)
gramacy2(xbest)

lhs_point <- read_csv('../code/x_dg_0.csv', col_names =FALSE)
# the columns in the result: (acquired point x1, x2), min dist, tol, lowest_prob, a number that indicates algorithm stops there
joint_point <- read_csv("../code/dg_joint_pareto_final_seed0.csv", col_names = FALSE)
joint_point$type <- ifelse(is.nan(joint_point$X5), "exploration", "exploitation")
joint_point$shape <- ifelse(is.nan(joint_point$X5), 15, 17)
n <- nrow(joint_point)


pdf("figures/gramacy_surface.pdf", width = 9, height = 5)
par(mfrow = c(1, 2), mar = c(3, 3, 3, 1), xpd = TRUE)
image(grid, grid, matrix(yp1, nrow = length(grid)), col = viridis(128),
      xlab = "", ylab = "", main = "Gramacy1",
      xaxt = "n", yaxt = "n", breaks = breaks1, cex.main = 1.2)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
contour(grid, grid, matrix(yp1, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lwd = 2)
contour(grid, grid, matrix(yp2, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lty = 2, lwd = 2)
points(lhs_point, col = alpha("white",.8), pch = 16, cex = 1.2)
points(joint_point$X1[2:n], joint_point$X2[2:n], col = alpha("cyan", .8), pch = joint_point$shape[2:n], cex = 1.2)
points(xbest, col = alpha("red",.8), pch = 17, cex = 1.5)
image(grid, grid, matrix(yp2, nrow = length(grid)), col = viridis(128),
      xlab = "", ylab = "", main = "Gramacy2",
      xaxt = "n", yaxt = "n", breaks = breaks2, cex.main = 1.2)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
contour(grid, grid, matrix(yp1, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lty = 2, lwd = 2)
contour(grid, grid, matrix(yp2, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lwd = 2)
points(lhs_point, col = alpha("white",.8), pch = 16, cex = 1.2)
points(joint_point$X1[2:n], joint_point$X2[2:n], col = alpha("cyan", .8), pch = joint_point$shape[2:n], cex = 1.2)
points(xbest, col = alpha("red",.8), pch = 17, cex = 1.5)
axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
dev.off()

# Figure 2: Slices of Multimodal and Camelback --------------------------------

### see Figures_Python.py

# Figure 3: Demonstration of exploitation iterations --------------------------


joint_prob1 <- read_csv('joint_prob1.csv', col_names = FALSE)
joint_prob2 <- read_csv('joint_prob2.csv', col_names = FALSE)

# mm_cb ----------------------------------------------------------------------

breaks1 <- seq(0, max(joint_prob1), length = 129)
breaks2 <- seq(0, max(joint_prob2), length = 129)

# Set up ----------------------------------------------------------------------

grid <- seq(0, 1, length = 101) 
xp <- as.matrix(expand.grid(grid, grid))
yp1 <- multimodal(xp)
yp2 <- camel(xp)
# 
# xbest = matrix(c(0.86, 0.52),nrow=1)
# multimodal(xbest)
# camel(xbest)
ind1 <- 6
ind2 <- 7

lhs_point <- read_csv('x_mm_cb_0.csv', col_names =FALSE)
# the columns in the result: (acquired point x1, x2), min dist, tol, lowest_prob, a number that indicates algorithm stops there
joint_point <- read_csv("mm_cb_joint_pareto_final_seed0.csv", col_names = FALSE)
joint_point$type <- ifelse(is.nan(joint_point$X5), "exploration", "exploitation")
joint_point$shape <- ifelse(is.nan(joint_point$X5), 15, 17)

mu1_1 <- read_csv("mu1_1.csv", col_names = FALSE)
mu2_1 <- read_csv("mu2_1.csv", col_names = FALSE)
mu1_2 <- read_csv("mu1_2.csv", col_names = FALSE)
mu2_2 <- read_csv("mu2_2.csv", col_names = FALSE)

pdf("sequential.pdf", width = 13.5, height = 5)
par(mfrow = c(1, 3), mar = c(3, 3, 3, 1), xpd = TRUE)
image(grid, grid, t(as.matrix(joint_prob1)), col = viridis(128),
      xlab = "", ylab = "", main = paste0("Iteration ", ind1-1),
      xaxt = "n", yaxt = "n", breaks = breaks1, cex.main = 1.2)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
contour(grid, grid, matrix(yp1, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lwd = 2)
contour(grid, grid, matrix(yp2, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lty = 2, lwd = 2)
contour(grid, grid, t(as.matrix(mu1_1)), add = TRUE, level = 0, 
        col = "red", lwd = 2)
contour(grid, grid, t(as.matrix(mu2_1)), add = TRUE, level = 0, 
        col = "red", lty = 2, lwd = 2)
points(lhs_point, col = alpha("white", 0.8), pch = 16, cex = 1.2)
points(joint_point$X1[2:(ind1-1)], joint_point$X2[2:(ind1-1)], col = alpha("cyan", .8), pch = joint_point$shape[2:(ind1-1)], cex = 1.2)
points(joint_point$X1[ind1], joint_point$X2[ind1], col = alpha("red", 1), pch = 17, cex = 1.5)

image(grid, grid, t(as.matrix(joint_prob2)), col = viridis(128),
      xlab = "", ylab = "", main = paste0("Iteration ",ind2-1),
      xaxt = "n", yaxt = "n", breaks = breaks2, cex.main = 1.2)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
contour(grid, grid, matrix(yp1, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lty = 2, lwd = 2)
contour(grid, grid, matrix(yp2, nrow = length(grid)), add = TRUE, level = 0, 
        col = "white", lwd = 2)
contour(grid, grid, t(as.matrix(mu1_2)), add = TRUE, level = 0, 
        col = "red", lwd = 2)
contour(grid, grid, t(as.matrix(mu2_2)), add = TRUE, level = 0, 
        col = "red", lty = 2, lwd = 2)
points(lhs_point, col = alpha("white", .8), pch = 16, cex = 1.2)
points(joint_point$X1[2:(ind2-1)], joint_point$X2[2:(ind2-1)], col = alpha("cyan",.8), pch = joint_point$shape[2:(ind2-1)], cex = 1.2)
points(joint_point$X1[ind2], joint_point$X2[ind2], col = alpha("red",1), pch = 17, cex = 1.5)
axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
dev.off()

# Figure 4: Tricands and Pareto front demonstration ---------------------------

# tricands ------------------------------------------------------------------------

# Set up ----------------------------------------------------------------------

grid <- seq(0, 1, length = 101) # denser grid for prettier plots
xp <- as.matrix(expand.grid(grid, grid))
s1 <- read_csv("s1.csv", col_names = FALSE)
s2 <- read_csv("s2.csv", col_names = FALSE)
yp1 <- s1$X1
yp2 <- s2$X1

breaks1 <- seq(min(s1), max(s1), length = 129)
breaks2 <- seq(min(s2), max(s2), length = 129)

pareto_front <- read_csv('pareto_front.csv', col_names = FALSE)
colnames(pareto_front) <- c("X1", "X2", "S1", "S2", "PF")


lhs_point <- read_csv('x_mm_cb_0.csv', col_names =FALSE)
lhs_point$shape <- 16

joint_point <- read_csv("mm_cb_joint_pareto_final_seed0.csv", col_names = FALSE)
acquired_point <- joint_point[2:8,1:2]
acquired_point$shape <- 17
all_point <- rbind(lhs_point, acquired_point)
X <- cbind(all_point$X1, all_point$X2)
int <- tricands.interior(X)
fr <- tricands.fringe(X, p = 0.5)
cands <- data.frame(tricands(X))
cands$PF <- pareto_front$PF
cands$shape <- ifelse(cands$PF==0, 18, 17)

pdf("tricands_pareto.pdf", width = 13.5, height = 5)
par(mfrow = c(1, 3), mar = c(4, 4, 3, 1), xpd = TRUE)
image(grid, grid, matrix(yp1, nrow = length(grid)), col = viridis(128),
      xlab = "", ylab = "", main = "Multimodal",
      xaxt = "n", yaxt = "n", breaks = breaks1, cex.main = 1.8)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
points(X, col = alpha("white", 0.8), pch = all_point$shape, cex = 2.2)
for (i in 1:nrow(int$tri))
  lines(X[c(int$tri[i, ], int$tri[i, 1]), ], col = "white")
arrows(fr$XB[, 1], fr$XB[, 2], fr$XF[, 1], fr$XF[, 2], lty = 2, col = "white")
points(cands$X1, cands$X2, col = 2, pch = cands$shape, cex = 2.5)


image(grid, grid, matrix(yp2, nrow = length(grid)), col = viridis(128),
      xlab = "", ylab = "", main = "Camelback",
      xaxt = "n", yaxt = "n", breaks = breaks2, cex.main = 1.8)
text(0.5, -0.1, expression("x"[1]), cex = 1.2)
text(-0.1, 0.5, expression("x"[2]), cex = 1.2)
points(all_point$X1, all_point$X2, col = alpha("white", 0.8), pch = all_point$shape, cex = 2.5)
for (i in 1:nrow(int$tri))
  lines(X[c(int$tri[i, ], int$tri[i, 1]), ], col = "white")
arrows(fr$XB[, 1], fr$XB[, 2], fr$XF[, 1], fr$XF[, 2], lty = 2, col = "white")
points(cands$X1, cands$X2, col = 2, pch = cands$shape, cex = 2.5)

axis(1, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))
axis(2, at = seq(0, 1, by = 0.2), labels = c(0, NA, NA, NA, NA, 1))

# pareto_front ------------------------------------------------------------------------

# Set up ----------------------------------------------------------------------

pareto_front <- read_csv('pareto_front.csv', col_names = FALSE)
colnames(pareto_front) <- c("X1", "X2", "S1", "S2", "PF")

pareto <- pareto_front[pareto_front$PF==1,]
pareto <- pareto[order(pareto$S2, decreasing = T),]

shape <- ifelse(pareto_front$PF==0, 18, 17)

plot(pareto_front$S1[pareto_front$PF==0], pareto_front$S2[pareto_front$PF==0], xlab = "Multimodal SD", ylab = "Camelback SD", main = "Pareto front of SD", cex.main = 1.8, cex = 2.5, pch = 18, col = "red", xlim = range(pareto_front$S1), ylim = range(pareto_front$S2))
points(pareto_front$S1[pareto_front$PF==1], pareto_front$S2[pareto_front$PF==1], col = "red", pch = 17, cex = 2.5)
segments(x0 = 0, x1 = pareto$S1[1], y0 = pareto$S2[1], y1 = pareto$S2[1], lty = "dashed", col = "red")
segments(x0 = pareto$S1[1], x1 = pareto$S1[1], y0 = pareto$S2[1], y1 = pareto$S2[2], lty = "dashed", col = "red")
segments(x0 = pareto$S1[1], x1 = pareto$S1[2], y0 = pareto$S2[2], y1 = pareto$S2[2], lty = "dashed", col = "red")
segments(x0 = pareto$S1[2], x1 = pareto$S1[2], y0 = pareto$S2[2], y1 = pareto$S2[3], lty = "dashed", col = "red")
segments(x0 = pareto$S1[2], x1 = pareto$S1[3], y0 = pareto$S2[3], y1 = pareto$S2[3], lty = "dashed", col = "red")
segments(x0 = pareto$S1[3], x1 = pareto$S1[3], y0 = pareto$S2[3], y1 = 0, lty = "dashed", col = "red")
dev.off()

# Figure 5: Simulation results ------------------------------------------------

## Make three plots in the same place ##

### Make result plots for all functions
r <- 1
plotz <- list()
funcz <- c("dg", "mm_cb", "mm_ishigami")
for (func in funcz){
  reps <- 50
  if (func == "dg" | func == "mm_cb"){
    n0 <- 5
    budget <- 20
    d <- 2
  }
  if (func == "mm_ishigami"){
    n0 <- 10
    budget <- 30
    d <- 3
    func_name <- "Multimodal3-Ishigami-Linear3"
  }
  if (func == "dg") func_name <- "Double Gramacy"
  if (func == "mm_cb") func_name <- "Multimodal-Camelback"
  
  alt_entropy <- alt_pareto <- joint_pareto <- array(NA, c(reps, budget+1, d+4))
  methods <- c("alt_entropy", "alt_pareto", "joint_pareto")
  for (i in 1:reps){
    for (method in methods){
      seed <- i-1
      res <- read_csv(paste0("result/", func, "_", method, "_final_seed", seed, ".csv"), col_names = F)
      if (method == "alt_entropy") alt_entropy[i,,] <- as.matrix(res)
      else if(method == "alt_pareto") alt_pareto[i,,] <- as.matrix(res)
      else if(method == "joint_pareto") joint_pareto[i,,] <- as.matrix(res)
    }
  }
  
  lhs <- array(NA, c(reps, budget+1, d+1))
  for (i in 1:reps){
    seed <- i-1
    res <- read_csv(paste0("result/", func, "_lhs_final_seed", seed, ".csv"), col_names = F)
    lhs[i,,] <- as.matrix(res[(n0+1):(n0+budget+1),])
  }
  
  # min_dist: col d+1
  # save the original
  joint_pareto_original <- joint_pareto
  alt_entropy_original <- alt_entropy
  alt_pareto_original <- alt_pareto
  
  # Find the last non-NA value in each row
  last_non_na_joint_pareto <- apply(joint_pareto[,,(d+1)], 1, function(row) tail(na.omit(row), 1))
  last_non_na_alt_entropy <- apply(alt_entropy[,,(d+1)], 1, function(row) tail(na.omit(row), 1))
  last_non_na_alt_pareto <- apply(alt_pareto[,,(d+1)], 1, function(row) tail(na.omit(row), 1))
  
  # fill in NaN with the last non NaN value for each iteration
  for (i in 1:reps){
    joint_pareto[i,is.nan(joint_pareto[i,,(d+1)]),(d+1)] <- last_non_na_joint_pareto[i]
    alt_entropy[i,is.nan(alt_entropy[i,,(d+1)]),(d+1)] <- last_non_na_alt_entropy[i]
    alt_pareto[i,is.nan(alt_pareto[i,,(d+1)]),(d+1)] <- last_non_na_alt_pareto[i]
  }
  
  # set lower bound as 1e-3
  joint_pareto_original2 <- joint_pareto
  alt_entropy_original2 <- alt_entropy
  alt_pareto_original2 <- alt_pareto
  
  joint_pareto[,,(d+1)] <- ifelse(joint_pareto[,,(d+1)] < 1e-3, 1e-3, joint_pareto[,,(d+1)])
  alt_entropy[,,(d+1)] <- ifelse(alt_entropy[,,(d+1)] < 1e-3, 1e-3, alt_entropy[,,(d+1)])
  alt_pareto[,,(d+1)] <- ifelse(alt_pareto[,,(d+1)] < 1e-3, 1e-3, alt_pareto[,,(d+1)])
  
  method_list <- c("alt_entropy", "alt_pareto", "joint_pareto", "lhs")
  
  min_dist <- list()
  for (i in 1:length(method_list)){
    res_method <- eval(parse(text=paste0(method_list[i])))
    min_dist[[i]] <- matrix(NA, nrow = budget+1, ncol = 5)
    colnames(min_dist[[i]]) <- c("number", "median", "upper", "lower", "method")
    min_dist[[i]] <- as.data.frame(min_dist[[i]])
    min_dist[[i]]$number <- (n0):(n0+budget)
    min_dist[[i]]$median <- apply(res_method[,,(d+1)], MARGIN = 2, median)
    min_dist[[i]]$upper <- apply(res_method[,,(d+1)], MARGIN = 2, FUN = quantile, probs = .9)
    min_dist[[i]]$lower <- apply(res_method[,,(d+1)], MARGIN = 2, FUN = quantile, probs = .1)
    min_dist[[i]]$method <- method_list[i]
  }
  
  min_dist_all <- rbind(min_dist[[1]], min_dist[[2]], min_dist[[3]], min_dist[[4]])
  
  min_dist_all$method <- factor(min_dist_all$method,
                                levels = c("alt_entropy", "alt_pareto", "joint_pareto", "lhs"),
                                labels = c("Alt. Entropy", "Alt. Pareto", "jCL", "LHS"))
  
  # save plots in a list to put them in the same plot later
  # png(filename = paste0("plot_final/min_dist_", func, "_final.png"))
  plotz[[r]] <- ggplot(min_dist_all, aes(x = number, y = median, color = method,fill = method)) +
    geom_line(aes(linetype = method)) +  # Add lines with custom thickness
    labs(
      title = paste0(func_name),
      # x = "Number of Total Samples",
      # y = "Distance (log scale)",
      x = "",
      y = "",
      color = "Sampling Method",
      fill = "Sampling Method",
      linetype = "Sampling Method"
    ) +
    scale_y_log10() +
    geom_ribbon(aes(ymin = lower, ymax = upper, linetype = method), size = .5, alpha = 0.2) +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold", size = 16),  # Center and bold the title
      axis.title = element_text(face = "bold"),  # Bold axis labels
      legend.position = "top",  # Position legend at the top
      legend.title = element_text(face = "bold", size = 16),  # Bold legend title
      legend.text = element_text(size = 16)
    ) +
    scale_linetype_manual(values = c("jCL" = "solid", "Alt. Entropy" = "dashed", "Alt. Pareto" = "dotted", "LHS" = "dotdash")) +
    scale_fill_viridis_d() + 
    scale_color_viridis_d() 
  # print(plot)
  # dev.off()
  
  r = r + 1
}


library(ggpubr)


pdf(paste0("../../sequential-sampling/joint_paper/images/sim_result.pdf"), width = 14, height = 5)
result_all <- ggarrange(plotz[[2]], plotz[[1]], plotz[[3]], nrow = 1, common.legend = TRUE, hjust = -1)
annotate_figure(result_all,
                # left = text_grob(expression(D[n]), rot = 90, size = 16),
                bottom = text_grob("Number of Total Sample", size = 16))
dev.off()
