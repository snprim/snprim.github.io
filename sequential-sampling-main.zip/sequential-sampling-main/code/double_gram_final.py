# Double contour location final version
# Function: 
#     double_gram: multimodal and camel with two ideal points
# Surrogate model: 
#     deepgp (R)
# Three choices of method: 
#     (1) joint_pareto: starts with joint but triggers pareto when joint probability is less than 0.2
#     (2) alt_entropy: alternating entropy by Cole et al
#     (3) alt_pareto: alterating pareto by Booth et al

import sys
sys.path.append('code')
import utils_all as utils_all
import utils_double_gram as double_gram
import numpy as np
import warnings
warnings.filterwarnings(action = "ignore", category = RuntimeWarning)
    # for entropy calculation on really small or large probabilities

import rpy2.robjects as robjects
from rpy2.robjects.packages import importr
from rpy2.robjects import numpy2ri
from rpy2.robjects import FloatVector

import time
import random

start_time = time.time()

args = sys.argv[1:]  # This will get all arguments except the script name
seed = int(args[0])
method = str(args[1])

random.seed(seed)
budget = 20
n0 = 5
total = n0+budget
epsilon = 1e-3

error_margin = 1e-3
explore_prob = np.log(0.2)
tol_adjust = 0.9

# Activate numpy2ri to convert numpy arrays to R-compatible objects
numpy2ri.activate()
# Import the dgpsi package in R
DT = importr('deepgp')

robjects.r['set.seed'](seed)

# training set

file_name_x = 'code/data/x_dg_' + str(seed) + '.csv'
file_name_y = 'code/data/y_dg_' + str(seed) + '.csv'

train_X = np.loadtxt(file_name_x, delimiter=',')
train_Y = np.loadtxt(file_name_y, delimiter=',')

d = train_X.shape[1]
M = train_Y.shape[1]

result = np.zeros(((budget+1),(d+4)))
result[:] = np.nan

dgp_model1 = DT.fit_two_layer(train_X, FloatVector(train_Y[:,0]), true_g = 1e-6, nmcmc = 5000, cov = "matern", v = 2.5)
dgp_model1 = DT.trim(dgp_model1, 4000, 10)

dgp_model2 = DT.fit_two_layer(train_X, FloatVector(train_Y[:,1]), true_g = 1e-6, nmcmc = 5000, cov = "matern", v = 2.5)
dgp_model2 = DT.trim(dgp_model2, 4000, 10)

result[0,d] = min(np.sum(np.power(train_Y,2), axis = 1))

best_train = train_X[np.argmin(np.sum(np.power(train_Y,2), axis = 1)),:]

tol = (min(abs(train_Y).max(axis=1))*tol_adjust)
result[0,(d+1)] = tol

step = "exploit"

print("Opening distance: " + str(min(np.sum(np.power(train_Y,2), axis = 1))))


for i in range(budget):
    print(i)
    print('tol='+str(tol))

    ##### sequential sampling starts #####
    
    if method=="joint_pareto":
        # update lowest_prob
        new_X, lowest_prob = robjects.r['opt_joint_prob'](dgp_model1, dgp_model2, tol, best_train)
        if (-lowest_prob < explore_prob):
            step = "explore"
        else:
            step = "exploit"

        if step=="explore":
            print("pareto front")
            cands = utils_all.tricands(train_X)
            # predict on tricands
            dgp_pred1 = DT.predict_dgp2(dgp_model1, x = cands)
            mu1 = dgp_pred1.rx2('mean')
            var1 = dgp_pred1.rx2('s2')
            s1 = np.sqrt(var1)

            dgp_pred2 = DT.predict_dgp2(dgp_model2, x = cands)
            mu2 = dgp_pred2.rx2('mean')
            var2 = dgp_pred2.rx2('s2')
            s2 = np.sqrt(var2)

            objectives = np.column_stack((s1, s2))
            pareto_front_ind = np.where(utils_all.is_pareto(objectives, maximise=True))[0]
            id = np.random.choice(pareto_front_ind,size=1,replace=False)
            # save selected point
            new_X = cands[id]

        elif step=="exploit": 
            print("joint step")
            result[(i+1),(d+2)] = lowest_prob[0]

    elif method=="alt_entropy":
        print("alternating cole")
        if i%2 == 0:
            new_X = robjects.r['opt_ent'](dgp_model1)
        else:
            new_X = robjects.r['opt_ent'](dgp_model2)

    elif method=="alt_pareto":
        print("alternating booth")
        cands = utils_all.tricands(train_X)
        # predict on tricands
        dgp_pred1 = DT.predict_dgp2(dgp_model1, x = cands)
        mu1 = dgp_pred1.rx2('mean')
        var1 = dgp_pred1.rx2('s2')
        s1 = np.sqrt(var1)

        dgp_pred2 = DT.predict_dgp2(dgp_model2, x = cands)
        mu2 = dgp_pred2.rx2('mean')
        var2 = dgp_pred2.rx2('s2')
        s2 = np.sqrt(var2)

        # calculate entropy
        ent1 = utils_all.entropy(mu1, s1, 0)
        ent2 = utils_all.entropy(mu2, s2, 0)
        if i%2 == 0:
            objectives = np.column_stack((ent1, s1))
        else:
            objectives = np.column_stack((ent2, s2))
        pareto_front_ind = np.where(utils_all.is_pareto(objectives, maximise=True))[0]
        id = np.random.choice(pareto_front_ind,size=1,replace=False)
        new_X = cands[id]
    
    ##### sequential sampling ends #####

    result[(i+1),0:d] = new_X 
    new_Y = double_gram.double_gram(new_X)
    
    # check if tol should be updated
    if (method=="joint_pareto"):
        if (new_Y[:,0] > 0-tol and new_Y[:,0] < 0+tol and new_Y[:,1] > 0-tol and new_Y[:,1] < 0+tol):
            tol = (max(abs(new_Y[:,0]), abs(new_Y[:,1]))*tol_adjust)
        result[i+1,(d+1)] = tol
    
    # find new train_X and train_Y
    train_X = np.vstack((train_X, new_X))
    train_Y = np.vstack((train_Y, new_Y))
    
    # retrain DGP models
    prev_nmcmc = dgp_model1.rx2('nmcmc')[0]
    dgp_model1 = DT.fit_two_layer(train_X, FloatVector(train_Y[:,0]), true_g = 1e-6, nmcmc = 1000, cov = "matern", v = 2.5, w_0 = dgp_model1.rx2('w')[prev_nmcmc-1], theta_w_0 = dgp_model1.rx2('theta_w')[prev_nmcmc-1,:], theta_y_0 = dgp_model1.rx2('theta_y')[prev_nmcmc-1])
    dgp_model1 = DT.trim(dgp_model1, 500, 5)
  
    dgp_model2 = DT.fit_two_layer(train_X, FloatVector(train_Y[:,1]), true_g = 1e-6, nmcmc = 1000, cov = "matern", v = 2.5, w_0 = dgp_model2.rx2('w')[prev_nmcmc-1], theta_w_0 = dgp_model2.rx2('theta_w')[prev_nmcmc-1,:], theta_y_0 = dgp_model2.rx2('theta_y')[prev_nmcmc-1])
    dgp_model2 = DT.trim(dgp_model2, 500, 5)
    
    result[i+1,d] = min(np.sum(np.power(train_Y,2), axis = 1))
    best_train = train_X[np.argmin(np.sum(np.power(train_Y,2), axis = 1)),:]

    print("Current distance: " + str(min(np.sum(np.power(train_Y,2), axis = 1))))

    if (min(np.sum(np.power(train_Y,2), axis = 1)) < error_margin):
        print("best point found!")
        result[(i+1),(d+3)] = i+1
        break

# store result
result_name = 'result/dg_' + method + '_final_seed' + str(seed) + '.csv'

np.savetxt(result_name, result, delimiter=',', comments='')

end_time = time.time()
execution_time = end_time - start_time
print(f"Execution time: {execution_time:.6f} seconds")