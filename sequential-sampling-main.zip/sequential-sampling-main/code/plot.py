import os
import sys
sys.path.append('code')
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

import utils_mm_cb as mm_cb
import utils_double_gram as double_gram

from scipy.stats import norm
import warnings
warnings.filterwarnings(action = "ignore", category = RuntimeWarning)
    # for entropy calculation on really small or large probabilities

from GP import GPyModelEasy as GP
import random
import rpy2.robjects as robjects
from rpy2.robjects.packages import importr
from rpy2.robjects import numpy2ri
from rpy2.robjects import FloatVector

### plot using models from saved points, mm_cb ###

# Make two iterations side by side


budget = 20
g1 = np.linspace(0, 1, 101)
method = "joint_pareto"
# method = "alt_entropy"
# method = "alt_pareto"
seed = 49
random.seed(seed)
result_name = 'code/result/mm_cb_' + method + '_final_seed' + str(seed) + '.csv'
# the columns in the result: (acquired point x1, x2), min dist, tol, lowest_prob, a number that indicates algorithm stops there
model = np.loadtxt(result_name, delimiter=',')

test_X = np.loadtxt('code/data/test_x_mm_cb.csv', delimiter=',')
test_Y = np.loadtxt('code/data/test_y_mm_cb.csv', delimiter=',')

outcome_mm = test_Y[:,0].reshape(101,101)
outcome_cb = test_Y[:,1].reshape(101,101)

file_name_x = 'code/data/x_mm_cb_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'code/data/y_mm_cb_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')
d = 2
indz = [5,6]

# see how the surfaces change 
X = np.vstack((train_X, model[1:indz[0],0:d]))
new_Y = mm_cb.mm_cb(model[1:indz[0],0:d])
Y = np.vstack((train_Y, new_Y))

gp1 = GP.GPyModel(X, Y[:,0].reshape(-1,1))
gp1.nugbnd = [1e-16,1e-6]
gp1.rand_restarts = 10
gp1.Fit()
mu1, var1 = gp1.predict(test_X)
var1 = var1.reshape(-1,1)
s1 = np.sqrt(var1).reshape(-1,1)

gp2 = GP.GPyModel(X, Y[:,1].reshape(-1,1))
gp2.nugbnd = [1e-16,1e-6]
gp2.rand_restarts = 10
gp2.Fit()
mu2, var2 = gp2.predict(test_X)
var2 = var2.reshape(-1,1)
s2 = np.sqrt(var2).reshape(-1,1)

mu1_plot = mu1.reshape(101,101)
s1_plot = s1.reshape(101,101)

mu2_plot = mu2.reshape(101,101)
s2_plot = s2.reshape(101,101)

limit = 0

tol = min(model[1:indz[0],d+1])
prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)

joint_prob = (prob1*prob2).reshape(101, 101)

# plot two plots together 

fig, ax = plt.subplots(1, 2, figsize = (10,5))             

# First plot

plot1 = ax[0].imshow(joint_prob,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1)
CS = ax[0].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
CS_orig = ax[0].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
CS = ax[0].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
CS_orig = ax[0].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
ax[0].clabel(CS, inline=True, fontsize=6, levels = [0])
ax[0].plot(model[1:indz[0],0], model[1:indz[0],1], 'co', markersize = 4, label = method)
ax[0].plot(model[indz[0],0], model[indz[0],1],  marker='*', color='white', linestyle='None', markersize = 5, label = "current")
ax[0].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
ax[0].set_title('Joint probability, iter ' + str(indz[0]))
fig.colorbar(plot1, ax=ax[0])
ax[0].legend(loc = "lower left", framealpha = .3, fontsize = 7)
ax[0].text(.6, .95, 'max prob=' + str(round(np.exp(-model[indz[0],4]),2)), fontsize=10, color='white')
ax[0].text(.6, .9, 'tolerance=' + str(round(tol,2)), fontsize=10, color='white')

# refit model for second plot

X = np.vstack((train_X, model[1:indz[1],0:d]))
new_Y = mm_cb.mm_cb(model[1:indz[1],0:d])
Y = np.vstack((train_Y, new_Y))

gp1 = GP.GPyModel(X, Y[:,0].reshape(-1,1))
gp1.nugbnd = [1e-16,1e-6]
gp1.rand_restarts = 10
gp1.Fit()
mu1, var1 = gp1.predict(test_X)
var1 = var1.reshape(-1,1)
s1 = np.sqrt(var1).reshape(-1,1)

gp2 = GP.GPyModel(X, Y[:,1].reshape(-1,1))
gp2.nugbnd = [1e-16,1e-6]
gp2.rand_restarts = 10
gp2.Fit()
mu2, var2 = gp2.predict(test_X)
var2 = var2.reshape(-1,1)
s2 = np.sqrt(var2).reshape(-1,1)

mu1_plot = mu1.reshape(101,101)
s1_plot = s1.reshape(101,101)

mu2_plot = mu2.reshape(101,101)
s2_plot = s2.reshape(101,101)

limit = 0

tol = min(model[1:indz[1],d+1])
prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)

joint_prob = (prob1*prob2).reshape(101, 101)

# plot second plot

plot2 = ax[1].imshow(joint_prob,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1)
CS = ax[1].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
CS_orig = ax[1].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
CS = ax[1].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
CS_orig = ax[1].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
ax[1].clabel(CS, inline=True, fontsize=6, levels = [0])
ax[1].plot(model[1:indz[1],0], model[1:indz[1],1], 'co', markersize = 4, label = method)
ax[1].plot(model[indz[1],0], model[indz[1],1],  marker='*', color='white', linestyle='None', markersize = 5, label = "current")
ax[1].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
ax[1].set_title('Joint probability, iter ' + str(indz[1]))
fig.colorbar(plot2, ax=ax[1])
ax[1].legend(loc = "lower left", framealpha = .3, fontsize = 7)
ax[1].text(.6, .95, 'max prob=' + str(round(np.exp(-model[indz[1],4]),2)), fontsize=10, color='white')
ax[1].text(.6, .9, 'tolerance=' + str(round(tol,2)), fontsize=10, color='white')


plt.tight_layout()
filename = 'code/plotz/sequential_result' + str(indz[0]) + '.png'
plt.savefig(filename)


#################################################

# find training and test sets and points found by method
# make into gif

budget = 20
g1 = np.linspace(0, 1, 101)
method = "joint_pareto"
# method = "alt_entropy"
# method = "alt_pareto"
seed = 0
random.seed(seed)
result_name = 'code/result/mm_cb_' + method + '_final_seed' + str(seed) + '.csv'
# the columns in the result: (acquired point x1, x2), min dist, tol, lowest_prob, a number that indicates algorithm stops there
model = np.loadtxt(result_name, delimiter=',')


test_X = np.loadtxt('code/data/test_x_mm_cb.csv', delimiter=',')
test_Y = np.loadtxt('code/data/test_y_mm_cb.csv', delimiter=',')

outcome_mm = test_Y[:,0].reshape(101,101)
outcome_cb = test_Y[:,1].reshape(101,101)

file_name_x = 'code/data/x_mm_cb_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'code/data/y_mm_cb_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')
d = 2

for ind2 in range(2,budget):
    print(ind2)
    # see how the surfaces change 
    X = np.vstack((train_X, model[1:ind2,0:d]))
    new_Y = mm_cb.mm_cb(model[1:ind2,0:d])
    Y = np.vstack((train_Y, new_Y))

    gp1 = GP.GPyModel(X, Y[:,0].reshape(-1,1))
    gp1.nugbnd = [1e-16,1e-6]
    gp1.rand_restarts = 10
    gp1.Fit()
    mu1, var1 = gp1.predict(test_X)
    var1 = var1.reshape(-1,1)
    s1 = np.sqrt(var1).reshape(-1,1)
    
    gp2 = GP.GPyModel(X, Y[:,1].reshape(-1,1))
    gp2.nugbnd = [1e-16,1e-6]
    gp2.rand_restarts = 10
    gp2.Fit()
    mu2, var2 = gp2.predict(test_X)
    var2 = var2.reshape(-1,1)
    s2 = np.sqrt(var2).reshape(-1,1)

    mu1_plot = mu1.reshape(101,101)
    s1_plot = s1.reshape(101,101)

    mu2_plot = mu2.reshape(101,101)
    s2_plot = s2.reshape(101,101)

    limit = 0

    tol = min(model[1:ind2,d+1])
    prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
    prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)

    joint_prob = (prob1*prob2).reshape(101, 101)

    # plot three plots together 

    fig, ax = plt.subplots(1, 3, figsize = (15,5))             
    plot1 = ax[0].imshow(mu1_plot,extent = (0,1,0,1), origin='lower')
    CS = ax[0].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[0].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
    CS = ax[0].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[0].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
    ax[0].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[0].plot(model[1:ind2,0], model[1:ind2,1], 'co', markersize = 4, label = method)
    ax[0].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[0].set_title('predicted mm')
    fig.colorbar(plot1, ax=ax[0])
    ax[0].legend(loc = "lower left", framealpha = .3, fontsize = 7)

    plot2 = ax[1].imshow(mu2_plot,extent = (0,1,0,1), origin='lower')
    CS = ax[1].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[1].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
    CS = ax[1].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[1].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
    ax[1].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[1].plot(model[1:ind2,0], model[1:ind2,1], 'co', markersize = 4, label = method)
    ax[1].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[1].set_title('predicted cb')
    fig.colorbar(plot2, ax=ax[1])
    ax[1].legend(loc = "lower left", framealpha = .3, fontsize = 7)

    plot3 = ax[2].imshow(joint_prob,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1)
    CS = ax[2].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[2].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
    CS = ax[2].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[2].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
    ax[2].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[2].plot(model[1:ind2,0], model[1:ind2,1], 'co', markersize = 4, label = method)
    ax[2].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[2].set_title('negative joint probability, iter ' + str(ind2))
    fig.colorbar(plot3, ax=ax[2])
    ax[2].legend(loc = "lower left", framealpha = .3, fontsize = 7)
    ax[2].text(.6, .95, 'max prob=' + str(round(np.exp(-model[ind2,4]),2)), fontsize=10, color='white')

    plt.tight_layout()
    filename = 'code/plotz/sequential_result' + str(ind2) + '.png'
    plt.savefig(filename)


# Folder containing PNG images
image_folder = "plot_for_gif"

# Output GIF file name
output_gif = "gif/mm_cb_seq_result_" + method + "_seed" + str(seed) + ".gif"

# Get all PNG files from the folder
png_files = [f for f in os.listdir(image_folder) if f.endswith('.png')]

# Sort files to ensure correct order (optional, based on filenames)
# png_files.sort()

# Load images
images = [Image.open(os.path.join(image_folder, file)) for file in png_files]

# Save as GIF
images[0].save(
    output_gif,
    save_all=True,
    append_images=images[1:],  # Add the rest of the images
    duration=2000,             # Duration between frames (in milliseconds)
    loop=0                    # Number of loops (0 = infinite)
)

print(f"GIF saved as {output_gif}")

####################################################
### plot using models from saved points, mm_cb, with SD, joint_pareto_twenty ###

# find training and test sets and points found by method
xbest = np.array([[0.86, 0.52]])
budget = 20
g1 = np.linspace(0, 1, 101)
method = "joint_pareto"
seed = 14
random.seed(seed)
result_name = 'result/mm_cb_' + method + '_final_seed' + str(seed) + '.csv'
model = np.loadtxt(result_name, delimiter=',')

test_X = np.loadtxt('data/test_x_mm_cb.csv', delimiter=',')
test_Y = np.loadtxt('data/test_y_mm_cb.csv', delimiter=',')

outcome_mm = test_Y[:,0].reshape(101,101)
outcome_cb = test_Y[:,1].reshape(101,101)

file_name_x = 'data/x_mm_cb_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'data/y_mm_cb_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')

for ind2 in range(2,budget):
    print(ind2)
    # see how the surfaces change 
    X = np.vstack((train_X, model[1:ind2,8:10]))
    new_Y = mm_cb.mm_cb(model[1:ind2,8:10])
    Y = np.vstack((train_Y, new_Y))

    gp1 = GP.GPyModel(X, Y[:,0].reshape(-1,1))
    gp1.nugbnd = [1e-16,1e-6]
    gp1.rand_restarts = 10
    gp1.Fit()
    mu1, var1 = gp1.predict(test_X)
    var1 = var1.reshape(-1,1)
    s1 = np.sqrt(var1).reshape(-1,1)
    
    gp2 = GP.GPyModel(X, Y[:,1].reshape(-1,1))
    gp2.nugbnd = [1e-16,1e-6]
    gp2.rand_restarts = 10
    gp2.Fit()
    mu2, var2 = gp2.predict(test_X)
    var2 = var2.reshape(-1,1)
    s2 = np.sqrt(var2).reshape(-1,1)

    mu1_plot = mu1.reshape(101,101)
    s1_plot = s1.reshape(101,101)

    mu2_plot = mu2.reshape(101,101)
    s2_plot = s2.reshape(101,101)

    limit = 0

    tol = min(model[1:ind2,11])
    prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
    prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)

    joint_prob = (prob1*prob2).reshape(101, 101)

    best1, best_var1 = gp1.predict(xbest)
    best_s1 = np.sqrt(best_var1)
    best2, best_var2 = gp2.predict(xbest)
    best_s2 = np.sqrt(best_var2)
    best_prob1 = norm.cdf((best1 - limit + tol) / best_s1) - norm.cdf((best1 - limit - tol) / best_s1)
    best_prob2 = norm.cdf((best2 - limit + tol) / best_s2) - norm.cdf((best2 - limit - tol) / best_s2)
    best_joint_prob = (best_prob1*best_prob2)

    # plot three plots together 

    fig, ax = plt.subplots(1, 3, figsize = (15,5))             
    plot1 = ax[0].imshow(s1_plot,extent = (0,1,0,1), origin='lower')
    CS = ax[0].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[0].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
    CS = ax[0].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[0].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
    ax[0].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[0].plot(model[1:ind2,8], model[1:ind2,9], 'co', markersize = 4, label = method)
    ax[0].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[0].set_title('predicted sd mm')
    fig.colorbar(plot1, ax=ax[0])
    ax[0].legend(loc = "lower left", framealpha = .3, fontsize = 7)

    plot2 = ax[1].imshow(s2_plot,extent = (0,1,0,1), origin='lower')
    CS = ax[1].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[1].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
    CS = ax[1].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[1].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
    ax[1].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[1].plot(model[1:ind2,8], model[1:ind2,9], 'co', markersize = 4, label = method)
    ax[1].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[1].set_title('predicted sd cb')
    fig.colorbar(plot2, ax=ax[1])
    ax[1].legend(loc = "lower left", framealpha = .3, fontsize = 7)

    plot3 = ax[2].imshow(np.log(joint_prob),extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1)
    CS = ax[2].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[2].contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
    CS = ax[2].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[2].contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
    ax[2].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[2].plot(model[1:ind2,8], model[1:ind2,9], 'co', markersize = 4, label = method)
    ax[2].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[2].set_title('negative joint probability, iter ' + str(ind2))
    fig.colorbar(plot3, ax=ax[2])
    ax[2].legend(loc = "lower left", framealpha = .3, fontsize = 7)
    ax[2].text(.6, .95, 'max prob=' + str(round(-model[ind2,12],2)), fontsize=10, color='white')
    ax[2].text(.6, .9, 'joint prob=' + str(np.round(best_joint_prob[0,0],2)), fontsize=10, color='white')

    plt.tight_layout()
    filename = 'plot_for_gif/sequential_result' + str(ind2) + '.png'
    plt.savefig(filename)


# Folder containing PNG images
image_folder = "plot_for_gif"

# Output GIF file name
output_gif = "gif/mm_cb_seq_result_" + method + "_final_seed" + str(seed) + ".gif"

# Get all PNG files from the folder
png_files = [f for f in os.listdir(image_folder) if f.endswith('.png')]

# Sort files to ensure correct order (optional, based on filenames)
# png_files.sort()

# Load images
images = [Image.open(os.path.join(image_folder, file)) for file in png_files]

# Save as GIF
images[0].save(
    output_gif,
    save_all=True,
    append_images=images[1:],  # Add the rest of the images
    duration=2000,             # Duration between frames (in milliseconds)
    loop=0                    # Number of loops (0 = infinite)
)

print(f"GIF saved as {output_gif}")


################################################################
### plot using models from saved points (double gramacy, SD) ###
################################################################

# find training and test sets and points found by method

budget = 20

g1 = np.linspace(0, 1, 101)
method = "joint_pareto"
seed = 9
result_name = 'result/dg_' + method + '_twenty_seed' + str(seed) + '.csv'
model = np.loadtxt(result_name, delimiter=',')

test_X = np.loadtxt('data/test_x_dg.csv', delimiter=',')
test_Y = np.loadtxt('data/test_y_dg.csv', delimiter=',')

outcome1 = test_Y[:,0].reshape(101,101)
outcome2 = test_Y[:,1].reshape(101,101)

file_name_x = 'data/x_dg_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'data/y_dg_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')

# Activate numpy2ri to convert numpy arrays to R-compatible objects
numpy2ri.activate()
# Import the dgpsi package in R
DT = importr('deepgp')
robjects.r['set.seed'](seed)
for ind2 in range(2,budget):
    print(ind2)
    # see how the surfaces change 
    # ind2 = 3
    X = np.vstack((train_X, model[1:ind2,8:10]))
    new_Y = double_gram.double_gram(model[1:ind2,8:10])
    Y = np.vstack((train_Y, new_Y))

    if ind2==2:
        dgp_model1 = DT.fit_two_layer(X, FloatVector(Y[:,0]), true_g = 1e-6, nmcmc = 5000, cov = "matern", v = 2.5)
        dgp_model1 = DT.trim(dgp_model1, 4000, 10)
        dgp_pred1 = DT.predict_dgp2(dgp_model1, x = test_X)
        
        mu1 = dgp_pred1.rx2('mean')
        var1 = dgp_pred1.rx2('s2')
        s1 = np.sqrt(var1)

        mu1_plot = mu1.reshape(101,101)
        s1_plot = s1.reshape(101,101)

        dgp_model2 = DT.fit_two_layer(X, FloatVector(Y[:,1]), true_g = 1e-6, nmcmc = 5000, cov = "matern", v = 2.5)
        dgp_model2 = DT.trim(dgp_model2, 4000, 10)
        dgp_pred2 = DT.predict_dgp2(dgp_model2, x = test_X)
        
        mu2 = dgp_pred2.rx2('mean')
        var2 = dgp_pred2.rx2('s2')
        s2 = np.sqrt(var2)

        mu2_plot = mu2.reshape(101,101)
        s2_plot = s2.reshape(101,101)
    
    else:
        prev_nmcmc = dgp_model1.rx2('nmcmc')[0]
        dgp_model1 = DT.fit_two_layer(X, FloatVector(Y[:,0]), true_g = 1e-6, nmcmc = 1000, cov = "matern", v = 2.5, w_0 = dgp_model1.rx2('w')[prev_nmcmc-1], theta_w_0 = dgp_model1.rx2('theta_w')[prev_nmcmc-1,:], theta_y_0 = dgp_model1.rx2('theta_y')[prev_nmcmc-1])
        dgp_model1 = DT.trim(dgp_model1, 500, 5)
        dgp_pred1 = DT.predict_dgp2(dgp_model1, x = test_X)
        mu1 = dgp_pred1.rx2('mean')
        var1 = dgp_pred1.rx2('s2')
        s1 = np.sqrt(var1)

        mu1_plot = mu1.reshape(101,101)
        s1_plot = s1.reshape(101,101)


        dgp_model2 = DT.fit_two_layer(X, FloatVector(Y[:,1]), true_g = 1e-6, nmcmc = 1000, cov = "matern", v = 2.5, w_0 = dgp_model2.rx2('w')[prev_nmcmc-1], theta_w_0 = dgp_model2.rx2('theta_w')[prev_nmcmc-1,:], theta_y_0 = dgp_model2.rx2('theta_y')[prev_nmcmc-1])
        dgp_model2 = DT.trim(dgp_model2, 500, 5)
        dgp_pred2 = DT.predict_dgp2(dgp_model2, x = test_X)
        mu2 = dgp_pred2.rx2('mean')
        var2 = dgp_pred2.rx2('s2')
        s2 = np.sqrt(var2)

        mu2_plot = mu2.reshape(101,101)
        s2_plot = s2.reshape(101,101)


    limit = 0
    tol = min(model[1:ind2,13])
    prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
    prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)
    joint_prob = (prob1*prob2).reshape(101, 101)

    # plot three plots together 

    fig, ax = plt.subplots(1, 3, figsize = (15,5))             
    plot1 = ax[0].imshow(s1_plot,extent = (0,1,0,1), origin='lower')
    CS = ax[0].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[0].contour(g1, g1, outcome1, levels = [0], colors = 'black')
    CS = ax[0].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[0].contour(g1, g1, outcome2, levels = [0], colors = 'black')
    ax[0].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[0].plot(model[1:ind2,8], model[1:ind2,9], 'co', markersize = 4, label = method)
    ax[0].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[0].plot(model[1:ind2,10], model[1:ind2,11], marker='o', color='pink', linestyle='None',markersize = 4, label = "pre_best")
    ax[0].plot(model[ind2+1,10], model[ind2+1,11], 'ro', markersize = 4, label = "best")
    ax[0].set_title('predicted SD dg1')
    fig.colorbar(plot1, ax=ax[0])
    ax[0].legend(loc = "lower left", framealpha = .3, fontsize = 7)

    plot2 = ax[1].imshow(s2_plot,extent = (0,1,0,1), origin='lower')
    CS = ax[1].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[1].contour(g1, g1, outcome1, levels = [0], colors = 'black')
    CS = ax[1].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[1].contour(g1, g1, outcome2, levels = [0], colors = 'black')
    ax[1].clabel(CS, inline=True, fontsize=6, levels=[0])
    ax[1].plot(model[1:ind2,8], model[1:ind2,9], 'co', markersize = 4, label = method)
    ax[1].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[1].plot(model[1:ind2,10], model[1:ind2,11], marker='o', color='pink', linestyle='None',markersize = 4, label = "pre_best")
    ax[1].plot(model[ind2+1,10], model[ind2+1,11], 'ro', markersize = 4, label = "best")
    ax[1].set_title('predicted SD dg2')
    fig.colorbar(plot2, ax=ax[1])
    ax[1].legend(loc = "lower left", framealpha = .3, fontsize = 7)

    plot3 = ax[2].imshow(joint_prob,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1)
    CS = ax[2].contour(g1, g1, mu1_plot, levels = [0], colors = 'red')
    CS_orig = ax[2].contour(g1, g1, outcome1, levels = [0], colors = 'black')
    CS = ax[2].contour(g1, g1, mu2_plot, levels = [0], colors = 'red')
    CS_orig = ax[2].contour(g1, g1, outcome2, levels = [0], colors = 'black')
    ax[2].clabel(CS, inline=True, fontsize=6, levels = [0])
    ax[2].plot(model[1:ind2,8], model[1:ind2,9], 'co', markersize = 4, label = method)
    ax[2].plot(train_X[:,0], train_X[:,1], 'bo', markersize = 4, label = "training")
    ax[2].plot(model[1:ind2,10], model[1:ind2,11], marker='o', color='pink', linestyle='None', markersize = 4, label = "pre_best")
    ax[2].plot(model[ind2+1,10], model[ind2+1,11], 'ro', markersize = 4, label = "best")
    ax[2].set_title('joint probability, iter ' + str(ind2))
    fig.colorbar(plot3, ax=ax[2])
    ax[2].legend(loc = "lower left", framealpha = .3, fontsize = 7)
    ax[2].text(.6, .95, 'max prob=' + str(round(-model[ind2,14],2)), fontsize=10, color='white')

    plt.tight_layout()
    filename = 'plot_for_gif/sequential_result_dg' + str(ind2) + '.png'
    plt.savefig(filename)


# Folder containing PNG images
image_folder = "plot_for_gif"

# Output GIF file name
output_gif = "gif/dg_seq_result_" + method + "_twenty_seed" + str(seed) + ".gif"

# Get all PNG files from the folder
png_files = [f for f in os.listdir(image_folder) if f.endswith('.png')]

# Sort files to ensure correct order (optional, based on filenames)
# png_files.sort()

# Load images
images = [Image.open(os.path.join(image_folder, file)) for file in png_files]

# Save as GIF
images[0].save(
    output_gif,
    save_all=True,
    append_images=images[1:],  # Add the rest of the images
    duration=2000,             # Duration between frames (in milliseconds)
    loop=0                    # Number of loops (0 = infinite)
)

print(f"GIF saved as {output_gif}")

###################################
########## plot 2D slice ##########
###################################



budget = 20
g1 = np.linspace(0, 1, 101)
method = "joint_pareto"
seed = 49
random.seed(seed)
result_name = 'code/result/mm_cb_' + method + '_final_seed' + str(seed) + '.csv'
# the columns in the result: (acquired point x1, x2), min dist, tol, lowest_prob, a number that indicates algorithm stops there
model = np.loadtxt(result_name, delimiter=',')

test_X = np.loadtxt('code/data/test_x_mm_cb.csv', delimiter=',')
test_Y = np.loadtxt('code/data/test_y_mm_cb.csv', delimiter=',')

outcome_mm = test_Y[:,0].reshape(101,101)
outcome_cb = test_Y[:,1].reshape(101,101)

file_name_x = 'code/data/x_mm_cb_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'code/data/y_mm_cb_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')
d = 2
indz = [11,12]


# see how the surfaces change 
X = np.vstack((train_X, model[1:indz[0],0:d]))
new_Y = mm_cb.mm_cb(model[1:indz[0],0:d])
Y = np.vstack((train_Y, new_Y))

gp1 = GP.GPyModel(X, Y[:,0].reshape(-1,1))
gp1.nugbnd = [1e-16,1e-6]
gp1.rand_restarts = 10
gp1.Fit()
mu1, var1 = gp1.predict(test_X)
var1 = var1.reshape(-1,1)
s1 = np.sqrt(var1).reshape(-1,1)

gp2 = GP.GPyModel(X, Y[:,1].reshape(-1,1))
gp2.nugbnd = [1e-16,1e-6]
gp2.rand_restarts = 10
gp2.Fit()
mu2, var2 = gp2.predict(test_X)
var2 = var2.reshape(-1,1)
s2 = np.sqrt(var2).reshape(-1,1)

mu1_plot = mu1.reshape(101,101)
s1_plot = s1.reshape(101,101)

mu2_plot = mu2.reshape(101,101)
s2_plot = s2.reshape(101,101)


limit = 0

tol = min(model[1:indz[0],d+1])
prob1 = norm.cdf((mu1 - limit + tol) / s1) - norm.cdf((mu1 - limit - tol) / s1)
prob2 = norm.cdf((mu2 - limit + tol) / s2) - norm.cdf((mu2 - limit - tol) / s2)

joint_prob = (prob1*prob2).reshape(101, 101)

# 2D slice plot 

lower1 = mu1_plot - 1.96*s1_plot
upper1 = mu1_plot + 1.96*s1_plot

lower2 = mu2_plot - 1.96*s2_plot
upper2 = mu2_plot + 1.96*s2_plot


slice_ind = 52

os.getcwd()
os.chdir("code")

plt.clf()
plt.plot(g1, outcome_mm[slice_ind], label = 'True Multimodal function', color = "black")
plt.plot(g1, mu1_plot[slice_ind], label = 'GP prediction')
plt.plot(g1, joint_prob[slice_ind], label = "Joint probability")
plt.plot(.86, 0, marker = 'o', color = "purple", markersize = 6)
plt.fill_between(g1, lower1[slice_ind], upper1[slice_ind], color='blue', alpha=0.2, label='Confidence Interval')
plt.legend()
filename = 'plotz/slice_mm.png'
plt.savefig(filename)

plt.clf()
plt.plot(g1, outcome_cb[slice_ind], label = 'True Camelback function', color = "black")
plt.plot(g1, mu2_plot[slice_ind], label = 'GP prediction')
plt.plot(g1, joint_prob[slice_ind], label = "Joint probability")
plt.plot(.86, 0, marker = 'o', color = "purple", markersize = 6)
plt.fill_between(g1, lower2[slice_ind], upper2[slice_ind], color='blue', alpha=0.2, label='Confidence Interval')
plt.legend()
filename = 'plotz/slice_cb.png'
plt.savefig(filename)

# plot mm and cb functions

plt.clf()
plot = plt.imshow(outcome_mm,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1, cmap='viridis')
plt.contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
plt.contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
plt.plot(0.86, 0.52, 'ro', markersize = 4, label = "optimal configuration")
plt.plot(train_X[:,0], train_X[:,1], 'co', markersize = 4, label = "training points")
plt.colorbar(plot)
plt.legend()
plt.xlabel("x1")
plt.ylabel("x2")
filename = 'plotz/mm.png'
plt.savefig(filename)

plt.clf()
plot = plt.imshow(outcome_cb,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1, cmap='viridis')
plt.contour(g1, g1, outcome_mm, levels = [0], colors = 'black')
plt.contour(g1, g1, outcome_cb, levels = [0], colors = 'black')
plt.plot(0.86, 0.52, 'ro', markersize = 4, label = "optimal configuration")
plt.plot(train_X[:,0], train_X[:,1], 'co', markersize = 4, label = "training points")
plt.colorbar(plot)
plt.legend()
plt.xlabel("x1")
plt.ylabel("x2")
filename = 'plotz/cb.png'
plt.savefig(filename)

# plot double gramacy

budget = 20
g1 = np.linspace(0, 1, 101)
seed = 49
random.seed(seed)

test_X = np.loadtxt('data/test_x_dg.csv', delimiter=',')
test_Y = np.loadtxt('data/test_y_dg.csv', delimiter=',')

outcome_dg1 = test_Y[:,0].reshape(101,101)
outcome_dg2 = test_Y[:,1].reshape(101,101)

file_name_x = 'data/x_dg_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'data/y_dg_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')

plt.clf()
plot = plt.imshow(outcome_dg1,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1, cmap='viridis')
plt.contour(g1, g1, outcome_dg1, levels = [0], colors = 'black')
plt.contour(g1, g1, outcome_dg2, levels = [0], colors = 'black')
plt.plot(0.3, 0.34, 'ro', markersize = 4, label = "optimal configuration")
plt.plot(train_X[:,0], train_X[:,1], 'co', markersize = 4, label = "training points")
plt.colorbar(plot)
plt.legend()
plt.xlabel("x1")
plt.ylabel("x2")
filename = 'plotz/dg1.png'
plt.savefig(filename)


plt.clf()
plot = plt.imshow(outcome_dg2,extent = (0,1,0,1), origin='lower', vmin = 0, vmax = 1, cmap='viridis')
plt.contour(g1, g1, outcome_dg1, levels = [0], colors = 'black')
plt.contour(g1, g1, outcome_dg2, levels = [0], colors = 'black')
plt.plot(0.3, 0.34, 'ro', markersize = 4, label = "optimal configuration")
plt.plot(train_X[:,0], train_X[:,1], 'co', markersize = 4, label = "training points")
plt.colorbar(plot)
plt.legend()
plt.xlabel("x1")
plt.ylabel("x2")
filename = 'plotz/dg2.png'
plt.savefig(filename)

