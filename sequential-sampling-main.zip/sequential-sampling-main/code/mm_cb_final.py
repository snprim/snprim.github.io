# Double contour location
# Function: 
#     mm_cb: multimodal and camel with two ideal points
# Surrogate model: 
#     gp: scikit-learn GPR
# Three choices of method: 
#     (1) joint_pareto: starts with joint but triggers pareto when joint probability is less than 0.2
#     (2) alt_entropy: alternating entropy by Cole et al
#     (3) alt_pareto: alterating pareto by Booth et al

import sys
sys.path.append('code')
import utils_all as utils_all
import utils_mm_cb as mm_cb
import numpy as np
import warnings
warnings.filterwarnings(action = "ignore", category = RuntimeWarning)
import time
import random
from GP import GPyModelEasy as GP

start_time = time.time()

args = sys.argv[1:]  # This will get all arguments except the script name
seed = int(args[0])
method = str(args[1])

random.seed(seed)
budget = 20
n0 = 5
total = n0+budget
epsilon = 1e-3

error_margin = 1e-3
explore_prob = np.log(0.2)
tol_adjust = 0.9

# training set

file_name_x = 'code/data/x_mm_cb_' + str(seed) + '.csv'
train_X = np.loadtxt(file_name_x, delimiter=',')
file_name_y = 'code/data/y_mm_cb_' + str(seed) + '.csv'
train_Y = np.loadtxt(file_name_y, delimiter=',')

d = train_X.shape[1]
M = train_Y.shape[1]

result = np.zeros(((budget+1),(d+4)))
result[:] = np.nan

gp1 = GP.GPyModel(train_X, train_Y[:,0].reshape(-1,1))
gp1.nugbnd = [1e-16,1e-6]
gp1.rand_restarts = 10
gp1.Fit()

gp2 = GP.GPyModel(train_X, train_Y[:,1].reshape(-1,1))
gp2.nugbnd = [1e-16,1e-6]
gp2.rand_restarts = 10
gp2.Fit()

result[0,d] = min(np.sum(np.power(train_Y,2), axis = 1))

best_train = train_X[np.argmin(np.sum(np.power(train_Y,2), axis = 1)),:]

tol = (min(abs(train_Y).max(axis=1))*tol_adjust)
result[0,(d+1)] = tol

step = "exploit"

print("Opening distance: " + str(min(np.sum(np.power(train_Y,2), axis = 1))))

for i in range(budget):
    print(i)
    print('tol='+str(tol))

    ##### sequential sampling starts #####
    if method=="joint_pareto":
        # update lowest_prob (log scale)
        new_X, lowest_prob = mm_cb.opt_joint_prob(gp1, gp2, tol, best_train)
        if (-lowest_prob < explore_prob):
            step = "explore"
        else:
            step = "exploit"

        if step == "explore":
            print("pareto front")
            cands = utils_all.tricands(train_X)
            # predict on tricands
            mu1, var1 = gp1.predict(cands)
            s1 = np.sqrt(var1)
            mu2, var2 = gp2.predict(cands)
            s2 = np.sqrt(var2)
            objectives = np.column_stack((s1, s2))
            pareto_front_ind = np.where(utils_all.is_pareto(objectives, maximise=True))[0]
            id = np.random.choice(pareto_front_ind,size=1,replace=False)
            # save selected point
            new_X = cands[id]

        elif step == "exploit": 
            print("joint step")
            result[i+1,(d+2)] = lowest_prob

    elif method=="alt_entropy":
        print("alternating cole")
        if i%2 == 0:
            new_X = mm_cb.opt_alt_cole(gp1)
        else:
            new_X = mm_cb.opt_alt_cole(gp2)
        
    elif method=="alt_pareto":
        print("alternating booth")
        cands = utils_all.tricands(train_X)
        # predict on tricands
        mu1, var1 = gp1.predict(cands)
        s1 = np.sqrt(var1)
        mu2, var2 = gp2.predict(cands)
        s2 = np.sqrt(var2)
        # calculate entropy
        ent1 = mm_cb.entropy(mu1, s1, 0)
        ent2 = mm_cb.entropy(mu2, s2, 0)
        if i%2 == 0:
            objectives = np.column_stack((ent1, s1))
        else:
            objectives = np.column_stack((ent2, s2))
        pareto_front_ind = np.where(utils_all.is_pareto(objectives, maximise=True))[0]
        id = np.random.choice(pareto_front_ind,size=1,replace=False)
        new_X = cands[id]
    
    ##### sequential sampling ends #####

    result[(i+1),0:d] = new_X 
    new_Y = mm_cb.mm_cb(new_X)
    
    # check if tol should be updated
    if (method=="joint_pareto"):
        if (new_Y[:,0] > 0-tol and new_Y[:,0] < 0+tol and new_Y[:,1] > 0-tol and new_Y[:,1] < 0+tol):
            tol = (max(abs(new_Y[:,0]), abs(new_Y[:,1]))*tol_adjust)
            print(tol)
        result[i+1,(d+1)] = tol
    
    # find new train_X and train_Y
    train_X = np.vstack((train_X, new_X))
    train_Y = np.vstack((train_Y, new_Y))

    # retrain GP models
    gp1 = GP.GPyModel(train_X, train_Y[:,0].reshape(-1,1))
    gp1.nugbnd = [1e-16,1e-6]
    gp1.rand_restarts = 10
    gp1.Fit()

    gp2 = GP.GPyModel(train_X, train_Y[:,1].reshape(-1,1))
    gp2.nugbnd = [1e-16,1e-6]
    gp2.rand_restarts = 10
    gp2.Fit()

    result[i+1,d] = min(np.sum(np.power(train_Y,2), axis = 1))
    best_train = train_X[np.argmin(np.sum(np.power(train_Y,2), axis = 1)),:]

    print("Current distance: " + str(min(np.sum(np.power(train_Y,2), axis = 1))))

    if (min(np.sum(np.power(train_Y,2), axis = 1)) < error_margin):
        print("best point found!")
        result[i+1,(d+3)] = i+1
        break

# store result
result_name = 'result/mm_cb_' + method + '_final_seed' + str(seed) + '.csv'
np.savetxt(result_name, result, delimiter=',', comments='')

end_time = time.time()
execution_time = end_time - start_time
print(f"Execution time: {execution_time:.6f} seconds")