import sys
sys.path.append('code')
import numpy as np
from pyDOE import lhs
import utils_mm_cb as mm_cb
import utils_double_gram as double_gram
import utils_mm_ishigami as mm_ishigami


# mm_cb

d = 2
n0 = 5
reps = 50
for i in range(reps):
    seed = i
    np.random.seed(919+seed)
    x = lhs(d, n0)
    y = mm_cb.mm_cb(x)
    file_name_x = 'code/data/x_mm_cb_' + str(seed) + '.csv'
    np.savetxt(file_name_x, x, delimiter=',', comments='')
    file_name_y = 'code/data/y_mm_cb_' + str(seed) + '.csv'
    np.savetxt(file_name_y, y, delimiter=',', comments='')

# double_gram

d = 2
reps = 50
n0 = 5
for i in range(reps):
    seed = i
    np.random.seed(919+seed)
    x = lhs(d, n0)
    y = double_gram.double_gram(x)
    file_name_x = 'code/data/x_dg_' + str(seed) + '.csv'
    np.savetxt(file_name_x, x, delimiter=',', comments='')
    file_name_y = 'code/data/y_dg_' + str(seed) + '.csv'
    np.savetxt(file_name_y, y, delimiter=',', comments='')

# mm_ishigami

d = 3
n0 = 10
reps = 50
for i in range(reps):
    seed = i
    np.random.seed(919+seed)
    x = lhs(d, n0)
    y = mm_ishigami.mm_ishigami(x)
    file_name_x = 'code/data/x_mm_ishigami_' + str(seed) + '.csv'
    np.savetxt(file_name_x, x, delimiter=',', comments='')
    file_name_y = 'code/data/y_mm_ishigami_' + str(seed) + '.csv'
    np.savetxt(file_name_y, y, delimiter=',', comments='')
